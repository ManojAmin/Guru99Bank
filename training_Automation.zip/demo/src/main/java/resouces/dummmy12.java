package resouces;

public class dummmy12 {

	public static void main(String[] args) {
		

		int[] n= {11,23,45,11,67,23,56,11,67,23,45,80};
		
		//int[] n= {11,23,45,67,23,56,11,67,45,80};
		
		for(int i=0;i<n.length;i++)
		{
			for(int j=i+1;j<n.length;j++)
			{
				if(n[i]==n[j])
				{
					System.out.println(n[i]);
				}
			}
		}
		
	}

}
