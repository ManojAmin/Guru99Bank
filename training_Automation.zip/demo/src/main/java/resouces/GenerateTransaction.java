package resouces;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GenerateTransaction {

	
	public List<String> alertValue() {
		
		Set<String> s=new HashSet<String>();
		s.add("Your transaction is successful 12193219213");
		s.add("your trasnsaction is successful 12193219213 with charge 10 on 12193219213");
		s.add("your transaction is successful 12193219213 with charge 100 on 12193219213 and tax 5 on 12193219213");
		
		List<String> ss = new ArrayList<String>();
		
		int count=0;
		for(int i=0;i<3;i++)
		{
			for (String string : s) {
				if(count<8)
				{
				ss.add(string);
				}
				count++;
			}
			
		}
		System.out.println(count);
		return ss;
	}

}
