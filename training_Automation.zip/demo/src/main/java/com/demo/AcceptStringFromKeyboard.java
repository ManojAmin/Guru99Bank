package com.demo;

import java.util.LinkedHashSet;
import java.util.Scanner;
import java.util.TreeSet;

public class AcceptStringFromKeyboard {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter the string :");
		String str = s.nextLine();
		LinkedHashSet<Character> l1 = new LinkedHashSet<Character>();
		//TreeSet<Character> l1=new TreeSet<Character>();
		for(int i=0;i<str.length();i++)
		{
		l1.add(str.charAt(i));
		}
		for(char c : l1)
		{
		System.out.println(c);
		}

		//Character.isSpace(c)
	}

}
