package com.demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class ExceptionHandling {

	public static void main(String[] args) {
		
		checkedExceptions();
		//runTimeException();
		System.out.println("rest of code");		

	}

	private static void checkedExceptions() {
		
		handleFileNotFoundException();
		handleClassNotFoundException();
		
		System.out.println("after checked exception ");
		
	}
	private static void handleClassNotFoundException() {
		try {
			Class.forName("");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("after ClassNotFoundException ");
		
	}

	private static void handleFileNotFoundException() {
		try {
			FileInputStream f=new FileInputStream("C:\\file.txt");
			
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
		
		System.out.println("after FileNotFoundException ");
	}

	private static void runTimeException() {
		//Unchecked exception
		//The classes that inherit the RuntimeException are known as unchecked exceptions.
		
		handleArithmeticException();
		handleNullPointerException();
		
		System.out.println("after runTimeException ");
		
	}

	private static void handleNullPointerException() {
		try {
			String str=null;  
			System.out.println(str.length());
		} catch (NullPointerException e) {
			System.out.println(e);
		} finally {
			System.out.println("finally block");
		}
		System.out.println("after NullPointerException ");
		
	}

	private static void handleArithmeticException() {
		try {
			int data = 100 / 0;
		} catch (ArithmeticException e) {
			System.out.println(e);
		}
		finally
		{
			System.out.println("finally block");
		}
		System.out.println("rest of the code after ArithmeticException");
		
	}	

}
