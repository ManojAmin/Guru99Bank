package com.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AddDataToTheMap {

	public static void main(String[] args) {
		String s1="101=A",s2="102=B",s3="103=C",s4="104=D",s5="105=B";
		
		Map<Integer,String> m=new HashMap<Integer,String>();
		List<String> s=new ArrayList<String>();
		s.add(s1);s.add(s2);s.add(s3);s.add(s4);s.add(s5);		
		System.out.println(s);
		
		for (String str : s) {
			
			String[] v=str.split("=");
			int rno=Integer.parseInt(v[0]);
			m.put(rno, v[1]);
			
		}
		System.out.println(m);
		System.out.println(m.get(105));
	}

}
