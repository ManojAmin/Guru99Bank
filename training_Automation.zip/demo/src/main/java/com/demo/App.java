package com.demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class App 
{
    public static void main( String[] args )
    {        
        //listImpl();
    	//impSet();
    	//impMap();
    	//other();
    	int x=20;
    	x++;
    	System.out.println(++x);
    	x--;
    	System.out.println(--x);
    	
    	//Object[] s= {4,"5",true};
    	
    	Set<String> s=new HashSet<String>();
    	s.add("apple");
    	s.add("orange");
    	System.out.println(s.add("apple"));
    	s.add("apple");
    	s.add("banana");
    	
    	System.out.println(s);
    	
    	
    	Map<String,String> m=new HashMap<String,String>();
    	m.put(null, "aaa");
    	m.put("A", "text1");
    	m.put(null, "bbb");
    	m.put("B", "text2");
    	m.put(null, "ccc");
    	
    	System.out.println(m);
    	
    }
	
	private static void other() {
		String s1="Sachin";

		String s2="Sachin";

		String s3=new String("Sachin");

		System.out.println(s1.equals(s2));

		System.out.println(s1.equals(s3));

		System.out.println(s1==s2);

		System.out.println(s1==s3);
		
	}

	private static void listImpl() {
		List<String> l=new ArrayList<String>();
		
		l.add("Bangalore");
		l.add("Chennai");
		l.add("Mumbai");
		l.add("Delhi");
		
		System.out.println("List Size : " +l.size());
		System.out.println("List values : "+l);
		
		l.add(2, "Punjab");
		l.add("Mumbai");
		System.out.println("List Size : " +l.size());
		System.out.println("List values2 : ");
		for (String list : l) {
			System.out.println(list);
		}		
	}
	
	private static void impSet() {
		Set<String> s=new HashSet<String>();
		s.add("Bangalore");
		s.add("Chennai");
		s.add("Mumbai");
		s.add("Delhi");
		System.out.println("Set Size : " +s.size());
		System.out.println("Set values : "+s);
		
		s.add("Mumbai");
		System.out.println("Set Size : " +s.size());
		
		System.out.println("Set values2 : ");
		for (String set : s) {
			System.out.println(set);
		}		
	}
	private static void impMap() {
		Map<String,String> m=new HashMap<String,String>();
		m.put("Name", "ABC");
		m.put("Address", "Bangalore");
		m.put("Designation", "testing");
		
		System.out.println("Map Size : " +m.size());
		System.out.println("Map  values : "+m);
		
		m.put("Address", "Chennai");
		
		System.out.println("Map Size : " +m.size());
		System.out.println("Map values2 : ");
		
		for (String k : m.keySet()) {
			System.out.println("Key is : "+k+ " & Values is :" +m.get(k));
		}
		
		
	}
}
