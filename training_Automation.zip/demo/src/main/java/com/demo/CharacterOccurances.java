package com.demo;

import java.util.HashMap;

public class CharacterOccurances {

	public static void main(String[] args) {
		
		String str = "Cat catch the mouse in a paddy field";
		HashMap<Character,Integer> h=new HashMap<Character,Integer>(); 
		for(int i=0;i<str.length();i++)
		{
			char c=str.charAt(i);
			if(h.containsKey(c))
			{
				int count=h.get(c);
				h.put(c, count+1);
			}
			else
			{
				h.put(c,1);
			}		
		}
		
		for (Character s : h.keySet()) {
			System.out.println(s +" : "+ h.get(s));
		}
	}

}
