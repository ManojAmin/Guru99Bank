package com.demo;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;
import java.util.TreeSet;

public class Assignment1 {
	
	public static void main(String[] args) {
		//readFromTextFile();
		primeNumber();
		//fractionToWholeNumber();
		
		//readFile();

	}
	
	private static void readFile() {
		Map<String,String> h=new TreeMap<String,String>();
		try {
			DataInputStream d=new DataInputStream(new FileInputStream("C:\\CG\\file.txt"));
			String line=d.readLine();
			
			while(line!=null)
			{
				System.out.println(line);
				String[] values=line.split("=");
				h.put(values[0], values[1]);				
				line=d.readLine();
			}
			
			System.out.println("map values are :"+h);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
	}

	private static void readFromTextFile() {
		HashMap<String,String> h=new HashMap<String,String>();
		try {
			BufferedReader read1=new BufferedReader(new FileReader("C:\\CG\\file.txt"));
			String line=read1.readLine();
			while(line!=null)
			{
				System.out.println(line);
				String[] values=line.split("=");
				h.put(values[0], values[1]);				
				line=read1.readLine();
			}
			
			System.out.println("map values are :"+h);
		} catch (Exception e) {
			
			System.out.println(e.getMessage());
		}
		
	}
	
	private static void primeNumber() {		
		
		List<Integer> l=new ArrayList<Integer>();
		int count=0;
		
		for(int j=1;j<=20;j++)
		{
			if(j%2==1)
			{
				if(count%2==0) 
				{
					l.add(j);
				}
				count++;
			}
		}
		System.out.println(l);
	}
	
	private static void fractionToWholeNumber() {
		Scanner s=new Scanner(System.in);
		System.out.println("Enter  the fractional value :");
		float value=s.nextFloat();
		System.out.println(value);
		
		int n2=(int) (value*10);
		
		int n=(int) (n2/10);
		int n3=n2%10;
		
		if(n3<5)
		{			
			System.out.println("Whole number is :"+n);
		}
		else
		{
			int n4=n+1;
			System.out.println("Whole number is :"+n4);
		}
		
		
		
	}
}
