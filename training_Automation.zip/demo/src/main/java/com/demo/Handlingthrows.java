package com.demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Handlingthrows {

	public static void main(String[] args) {		
	
			try {
				readFile();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		System.out.println("rest of code in main method");
		
	}

	private static void readFile() throws IOException  {
		
		//If we throw a checked exception using throw keyword, it is must to handle the exception using catch block 
		//or the method must declare it using throws declaration.
		
		//It provides information to the caller of the method about the exception.
		FileInputStream f=new FileInputStream("C:\\Automation\\BDD\\src\\main\\java\\resources\\credentialq.properties");
		System.out.println("rest of code in readFile method");
		
	}

}
