package com.demo;

public class Others {

	
	public static void main(String[] args) {

			String str = "demo";
			int count = 1;
			for (int i=0; i<str.length(); i++){
			System.out.print(str.charAt(i));
			for (int j=1 ; j<count; j++){
			System.out.print(str.charAt(i));
			}
			count++;
			}
			
			
	
	}
}



