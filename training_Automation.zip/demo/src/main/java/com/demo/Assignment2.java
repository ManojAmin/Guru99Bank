package com.demo;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Assignment2 {

	public static void main(String[] args) throws IOException {
		//ReadfromTextFile();
		//printOddNumber();
		revesrString();

	}	

	private static void revesrString() {
		String str = "Welcome to SCB";
		String[] s=str.split(" ");
		
		String rev=" ";
		for(int i=0;i<s.length;i++)
		{
			rev=s[i]+" "+rev;
		}
		System.out.println(rev);
	}

	private static void ReadfromTextFile() throws IOException {
		
		
		File file = new File("C:\\CG\\file.txt");
		FileReader fr = new FileReader(file);
		BufferedReader br = new BufferedReader(fr);			
			
			
		// Using ArrayList
		// ArrayList<String> list = new ArrayList<String>();
		
		// Using Set
		Set<String> list=new HashSet<String>();
		String Str2 = "";
		while ((Str2 = br.readLine()) != null) {
			list.add(Str2);

		}
		br.close();
		System.out.println(list);
		
	}
	
	private static void printOddNumber() {
		List<Integer> list=new ArrayList<Integer>();
		//Set<Integer> list=new HashSet<Integer>();
		int Num = 50;
		
		for (int i = 1; i <= Num; i+=4)
		{
			
			System.out.println("no of iterations" + i);
			list.add(i);
			System.out.println(list);
			if (i % 2 != 0)
			{
				
				list.add(i);
				System.out.println("odd values" + list);
			}
		}
	}
}
