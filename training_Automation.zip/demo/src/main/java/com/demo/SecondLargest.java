package com.demo;

public class SecondLargest {

	public static void main(String[] args) {
		
		int[] num= {12,45,90,11,35,9,33,87,99};
		System.out.println(Double.SIZE);
		int size=num.length;
		int large=num[0],sl=0,temp;
		
		if(size<=1)
		{
			System.out.println("There is no seconds largest element");
		}
		else
		{
			for(int i=0;i<size;i++)
			{
				if(large<=num[i])
				{
					temp=large;
					large=num[i];
					sl=temp;
				}
				else if(sl<=num[i])
				{
					sl=num[i];
				}
			}
			
			System.out.println("largest number :" +large);
			System.out.println(" seconds largest number :" +sl);
		}
		

	}

}
