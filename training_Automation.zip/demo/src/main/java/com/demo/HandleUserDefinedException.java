package com.demo;

public class HandleUserDefinedException {

	public static void main(String[] args) {
		
		//throw keyword is used to customize the Exception or create new user defined exception
		try {
			userDefinedExceptionHAndling(11);
		} catch (AgeException e) {		
			e.printStackTrace();
		}
		System.out.println("Rest of code...");
	}

	private static void userDefinedExceptionHAndling(int age) throws AgeException {
		
		  if(age<18) {   
	            throw new AgeException("Person is not eligible to vote");    
	        }  
	        else {  
	            System.out.println("Person is eligible to vote!!");
	        }
		  
		  String[] sss="welcome to automation".split("");
	        
		
	}
}
	
	class AgeException extends Exception  
	{  
	    public AgeException(String str)  
	    {  
	        // Calling constructor of parent Exception  
	        super(str);  
	    }  
	}  