package com.demo;

import java.util.TreeMap;

public class Interview {

	public static void main(String[] args) {
		String s;
		String s1="java";
		String s2="testing";
		System.out.println(s1.charAt(0)>s2.charAt(0));
		
		int[] n= {15,90,22,66};
		s="asdd";
		//System.out.println(n[4]);
		System.out.println(s);
		TreeMap<String,Integer> t=new TreeMap<String,Integer>();
		
		
		t.put("hdhd", 3);		
		t.put("aaa", 1);
		t.put("see", 8);
		t.put("bbb", 6);
		
		System.out.println(t);
	}

}
