package com.demo;

public class HandleThrowable {
	
	
	public static void main(String[] args) {
		
		try
		{
			handlingThrowable(11);
		}
		catch(Throwable e)
		{
			e.printStackTrace();
		}
		
		
	}

	private static void handlingThrowable(int age) {
		if(age<18) {   
	        throw new Error("Person is not eligible to vote");    
	    }  
	    else {  
	        System.out.println("Person is eligible to vote!!");
	    }
		
	}
	
}
