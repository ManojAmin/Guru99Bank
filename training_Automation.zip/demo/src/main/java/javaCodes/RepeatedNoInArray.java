package javaCodes;

import java.util.HashSet;
import java.util.Set;

public class RepeatedNoInArray {

	public static void main(String[] args) {
		
		int[] a= {10,44,22,90,10,45,22,10,56,22};
		
		
		Set<Integer> n=new HashSet<Integer>();
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]==a[j])
				{
					n.add(a[i]);
				}
			}
		}
		System.out.println(n);
	}

}
