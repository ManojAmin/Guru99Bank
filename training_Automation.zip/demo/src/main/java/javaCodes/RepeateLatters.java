package javaCodes;

public class RepeateLatters {

	public static void main(String[] args) {
		String s="manoj";
		
		System.out.println(s.length());

		for(int i=0;i<s.length();i++)
		{
			//System.out.print(s.charAt(i-1));
			for(int j=0;j<=i;j++)
			{
				System.out.print(s.charAt(i));
			}
		}
	}

}
