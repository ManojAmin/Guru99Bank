package javaCodes;

import java.util.Arrays;

public class SortingArray {

	public static void main(String[] args) {
		int[] a= {23,75,50,99,02,44,65};
		//Arrays.sort(a);
		
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				int tmp = 0;  
				//asc
				if(a[i]<a[j])
				{					
					tmp=a[i];
					a[i]=a[j];
					a[j]=tmp;
					
				}
			}
			System.out.println(a[i]);
		}
	}

}
