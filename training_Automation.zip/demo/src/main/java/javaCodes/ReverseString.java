package javaCodes;

public class ReverseString {

	public static void main(String[] args) {
		String s="manoj", rev = " ";
		char ch;
		for(int i=0;i<s.length();i++)
		{
			ch=s.charAt(i);
			rev=ch+rev;
		}
		System.out.println(rev);
	}
}
