package javaCodes;

import java.util.List;

import resouces.GenerateTransaction;

public class AlertTypeCount {

	public static void main(String[] args) {
		
		usingStringContainsLogic();
		//usingTransactionID();
		

	}

	private static void usingTransactionID() {
		int normal=0,charge=0,tax=0;
		GenerateTransaction tran=new GenerateTransaction();		
		List<String> s=tran.alertValue();
		for (String values : s) {
			String[] d=values.split(" ");
			
		}
		
	}

	private static void usingStringContainsLogic() {
		int normal=0,charge=0,tax=0;
		GenerateTransaction tran=new GenerateTransaction();		
		List<String> s=tran.alertValue();
		
		for (String values : s) {
			if(values.contains("tax"))
			{
				tax++;
			}
			else if(values.contains("charge"))
			{
				charge++;
			}
			else
			{
				normal++;
			}
		}
		
		System.out.println("Total normal transaction : "+normal);
		System.out.println("Total Charged transaction : "+charge);
		System.out.println("Total taxed transaction : "+tax);
		
	}

}
