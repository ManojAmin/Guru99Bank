package javaCodes;

import java.util.HashMap;
import java.util.Map;

public class WordsOccurenceInString {

	public static void main(String[] args) {
		
		String str="Cat catch the mouse in a paddy a field";
		Map<String,Integer> m=new HashMap<String,Integer>();
		String[] s=str.split(" ");
		
		for(int i=0;i<s.length;i++)
		{
			if(m.containsKey(s[i]))
			{
				int count=m.get(s[i]);
				m.put(s[i], count+1);
			}
			else
			{
				m.put(s[i], 1);
			}			
		}
		
		System.out.println(m);
		int[] n= {15,90,22,66};
		
		for (int i : n) {
			System.out.println(i);
		}
		String s1="java";
		String s2="testing";
		System.out.println(s1.charAt(0)>s2.charAt(0));
		
		String sss="welcome to automation";
		StringBuffer s22=new StringBuffer(sss);
		s22.reverse();
		System.out.println(s22);
	}
	
	

}
