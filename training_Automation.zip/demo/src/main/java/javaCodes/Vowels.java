package javaCodes;

public class Vowels {

	public static void main(String[] args) {
		String s="Shello world aeiouO";
		String c="";
		int j = 0,m=0;
		for (int i = 0; i < s.length(); i++) {
			c = s.charAt(i)+"";
			//c.toLowerCase();
			if (c.equalsIgnoreCase("a") || c.equalsIgnoreCase("e") || c.equalsIgnoreCase("i") || c.equalsIgnoreCase("o") || c.equalsIgnoreCase("u")) {
				j++;
			}
			else
			{
				if(!Character.isSpaceChar(s.charAt(i)))
				{
					m++;
				}
				
			}
		}
		System.out.println(j+" "+m);
	}

}
