package javaCodes;

class Parent1 {    
    
    void show1()   
    {   
        System.out.println("Parent method show1");   
    }   
    void show2()   
    {   
        System.out.println("Parent method show2");   
    }
}   
    
class Child1 extends Parent1 {  
    
    @Override  
    void show1()   
    {   
        System.out.println("Child method show1");   
    } 
    void show3()   
    {   
        System.out.println("Child method show3");   
    }
} 
    
public class Downcasting{  
    
    public static void main(String[] args)   
    {   
        Parent1 p = new Child1();  
        p.show1();
        p.show2();
        
        Child1 c=(Child1)p;
        c.show1();
        c.show2();
        c.show3();
    }   
}  