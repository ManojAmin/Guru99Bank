package javaCodes;

class Shape
{
	public void draw()
	{
		System.out.println("in draw of Shape");
	}
}

class Test extends Shape
{
	public void draw()
	{
		System.out.println("in draw of Test");
	}	
}

public class AA {

	public static void main(String[] args) {
		Shape obj1=new Test();		
		obj1.draw();
		
		//Test onb2=(Test) new Shape();
		//onb2.draw();

	}
}
