package javaCodes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class ReadDataFromTextFile {
	
	public static void main(String[] args) throws IOException 
	{
		BufferedReader b=new BufferedReader(new FileReader(new File("C:\\Automation\\demo\\src\\main\\java\\resouces\\file.txt")));
		System.out.println(b.readLine());
	}
	
}
