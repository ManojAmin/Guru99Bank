package javaCodes;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadDataFromExcel {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		
		Scanner s=new Scanner(System.in);
		System.out.println("Enter key : ");
		String search=s.nextLine();
		
		Map<String,String> m=new HashMap<String,String>();

		Workbook workbook = new XSSFWorkbook(new FileInputStream("C:\\Automation\\Guru99Bank\\src\\test\\resources\\inputDatas.xlsx"));		
		  Sheet sheet = workbook.getSheetAt(0);
		  
		  int lastRow = sheet.getLastRowNum();
		  for(int i=0; i<=lastRow; i++){
			  
			  Row row = sheet.getRow(i);
			  Cell valueCell = row.getCell(1);
			  Cell keyCell = row.getCell(0);
			  
			  //CellType c=valueCell.getCellType();
			  
			  String key = keyCell.getStringCellValue().trim() ;
			 String value = null;
			 			 
			  if(valueCell.getCellType()==CellType.STRING) {
				  
				   value =String.valueOf(valueCell.getStringCellValue().trim());
			  }
			  else if(valueCell.getCellType()==CellType.NUMERIC)
			  {
				   value =String.valueOf(NumberToTextConverter.toText(valueCell.getNumericCellValue()));
				  
			  }
			  else
			  {
				  System.out.println("other check");
			  }
			  
			  m.put(key,value);
		  }
		  
			
			 for (String keys : m.keySet()) { System.out.println(keys+ " : " +m.get(keys)
			  ); }
			 	  
		  System.out.println(m.get(search));
			
			// for (String key : m.keySet()) { System.out.println(m.get(key)); }
			 
		
	}

}
