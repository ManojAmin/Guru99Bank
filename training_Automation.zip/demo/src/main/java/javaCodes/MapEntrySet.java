package javaCodes;

import java.util.HashMap;
import java.util.Map;

public class MapEntrySet {

	public static void main(String[] args) {
		Map<String,String> m=new HashMap<String,String>();
		m.put("Name", "ABC");
		m.put("Address", "Bangalore");
		m.put("Designation", "testing");
		
		m.put("Address", "Chennai");
		
		System.out.println("Map Size : " +m.size());
		System.out.println(m.entrySet());
		
	}

}
