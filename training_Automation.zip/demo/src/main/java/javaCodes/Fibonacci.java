package javaCodes;

public class Fibonacci {

	static int n1=0,n2=1,n3;
	public static void main(String[] args) {
		
		//fibo();
		int num=10;
		System.out.println("Fibonaci numbers are :" +n1);
		System.out.println(n2);
		printFibonacci(num-2);

	}
	private static void printFibonacci(int num) {
		if(num>0)
		{
			n3=n1+n2;
			System.out.println(n3);
			n1=n2;
			n2=n3;
			printFibonacci(num-1);
		}
		
	}



	private static void fibo() {
		int f1=0,f2=1,f3;
		System.out.println("Fibonaci numbers are :" +f1);
		System.out.println(f2);
		for(int i=2;i<10;i++)
		{
			f3=f1+f2;
			System.out.println(f3);
			f1=f2;
			f2=f3;
		}
		
		
	}

}
