package javaCodes;

public class ArmstrongNumber {

	public static int f1=0,f2=1,f3;
	
	public static void main(String[] args) {

		int n=1634,n4=n,n2,n3,sum=0;		
		int num=String.valueOf(n).length();		
		for(int i=0;i<num;i++)
		{
			n2=n%10;
			n=n/10;
			n3=(int)Math.pow(n2, num);
			sum=sum+n3;
		}
		
		if(n4==sum)
		{
			System.out.println("Armstrong number");
		}
		else
		{
			System.out.println("Not a Armstrong number");
		}	
		
	
	}
}
