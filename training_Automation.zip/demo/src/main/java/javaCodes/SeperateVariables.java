package javaCodes;

public class SeperateVariables {

	public static void main(String[] args) {
		
		//oneMethod();
		method2();
	}

	private static void method2() {
		
		String s= "abcd1$?@23=+4efg";
		char c;
		String a = "",n = "",sp="";
		for(int i=0;i<s.length();i++)
		{
			c=s.charAt(i);
			if(Character.isAlphabetic(c))
			{
				a=a+c;
			}
			else if(Character.isDigit(c))
			{
				n=n+c;
			}
			else
			{				
				sp=sp+c;
			}
		}
		System.out.println("characters : "+a);
		System.out.println("Numbers :" +n);
		System.out.println("special characters :"+sp);
		//System.out.println(Character.isAlphabetic(c)+":"+c);
		
	}

	private static void oneMethod() {
		String s= "abcd1$?@23=+4efg";
		int asc ;
		String a="",n="",sp="";
		char c;
		
		for(int i=0;i<s.length();i++)
		{
			c=s.toLowerCase().charAt(i);
			
			asc=(int)c;
			if(asc>=97&&c<=122)
			{
				a=a+c;
			}
			else if(asc>=47&&c<=58)
			{
				n=n+c;
			}
			else
			{
				sp=sp+c;
			}
		}
		//65-90 97-122  ,48-57
		System.out.println("characters : "+a);
		System.out.println("Numbers :" +n);
		System.out.println("special characters :"+sp);
		char z=48;
		//System.out.println(z);
		
	}

}
