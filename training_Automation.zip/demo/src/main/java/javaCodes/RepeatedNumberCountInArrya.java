package javaCodes;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class RepeatedNumberCountInArrya {

	public static void main(String[] args) {
		int[] a = { 33, 56, 11, 56, 78, 33, 45, 67, 33, 11, 9 };

		Map<Integer, Integer> m = new HashMap<Integer, Integer>();
		Set<Integer> s = new HashSet<Integer>();

		for (int i = 0; i < a.length; i++) {
			if (!s.add(a[i])) {
				if (m.containsKey(a[i])) {
					int count = m.get(a[i]);
					m.put(a[i], ++count);
				} else {
					m.put(a[i], 2);
				}
			}
		}

		//System.out.println(s);
		System.out.println(m);

	}

}
