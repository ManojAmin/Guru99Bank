package javaCodes;

public class ReverseSentence {

	public static void main(String[] args) {
		String s="welcome to testing", rev="";
		
		String[] str=s.split(" ");
		
		for(int i=0;i<str.length;i++)
		{
			rev=str[i]+" "+rev;
		}
		
		System.out.println(rev);
	}

}
