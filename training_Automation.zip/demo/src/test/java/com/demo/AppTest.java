package com.demo;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
	public static void main(String[] args) {
		/*
		 * String s="Welocome to testing";
		 * 
		 * String[] s1=s.split(" ");
		 * 
		 * int n=s1.length;
		 * 
		 * for(int i=0;i<=n-1;i++) { System.out.print(s1[n-i-1] +" "); }
		 */
		
		
		
		int a=11;
		int a1=11;		
		System.out.println(a==a1);		
		Integer a3=12;		
		System.out.println(a==a3);  
		
		Integer a4=new Integer(11);
		System.out.println(a==a4);
		
		System.out.println("***********************************************************");
		
		
		
		String s1="java";
		System.out.println(s1.hashCode());
		String s2="java";
		System.out.println(s2.hashCode());
		System.out.println(s1==s2);
		
		String s4=new String("java");
		System.out.println(s4.hashCode());
		System.out.println(s1==s4);
		
		StringBuffer s5=new StringBuffer();
		s5.append("java");
		System.out.println(s5.hashCode());
		
		
		
		
		
	}
}
