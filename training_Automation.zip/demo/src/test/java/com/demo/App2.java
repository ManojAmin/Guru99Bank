package com.demo;
class C{
	public C() {
		System.out.println("C");
	}
	
	public void sam()
	{
		System.out.println(" In c");
	}
}

class A extends C{
	public A() {
		System.out.println("A");
	}
	
	public void sam()
	{
		System.out.println(" In A");
	}
}
/*
class B extends A {
	public B() {
		System.out.println("B");
	}
	
	public void sam()
	{
		System.out.println(" In B");
	}
}

class C extends B {
	public C() {
		System.out.println("C");
	}
} */

public class App2 extends A {
	public App2() {
		System.out.println("App2");
	}
	public static void main(String[] args) {
		
		App2 aa=new App2();
		aa.sam();
	}
	public void sam()
	{
		System.out.println(" In B");
	}

}
