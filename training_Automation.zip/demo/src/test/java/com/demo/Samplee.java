package com.demo;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Samplee {

	public static void main(String[] args) {
		
		int[] n= {1,4,5,3,1,6,2,4,1};
		
		Map<Integer,Integer> m=new HashMap<Integer,Integer>();
		System.out.println("repeated numbers");
		for(int i=0;i<n.length;i++)
		{
			for(int j=i+1;j<n.length;j++)
			{
				if(n[i]==n[j])
				{
					if(m.containsKey(n[i]))
					{
						
						m.put(n[i], m.get(n[i])+1);
					}
					else
					{
						m.put(n[i], 1);
					}
					
				}
			}
		}
		System.out.println(m);
	}

}
