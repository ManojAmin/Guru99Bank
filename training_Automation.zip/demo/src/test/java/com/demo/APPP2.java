package com.demo;

import java.io.IOException;

public class APPP2 {

	public static void main(String[] args) throws IOException {
String s="manoj born 1996 month of 02";
        
        String st="";
        
        String str1[]=s.split(" ");
        
        for(int i=0;i<str1.length;i++)
        {
           String rev=str1[i];
            if(i==2 || i==5)
            {
                 rev="";
            for(int j=0;j<str1[i].length();j++)
            {
                rev=str1[i].charAt(j)+rev;
            }
            }
            
            st=st+" "+rev;
        }
        
        System.out.println(st);}
	
}
