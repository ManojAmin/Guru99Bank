package com.javaTraining;

public class PrimeNumber {

	public static void main(String[] args) {
		int num=2369;
		boolean flag=false;
		
		if(num==1||num==0)
		{
			System.out.println(num+ " is a prime number");
		}
		else
		{
			for(int i=2;i<num;i++)
			{
				if(num%i==0)
				{
					flag=true;
					System.out.println(num+ " : is a prime number");
					break;
				}
			}
			if(!flag)
			{
				System.out.println(num+ " is not a prime number");
			}
		}

	}

}
