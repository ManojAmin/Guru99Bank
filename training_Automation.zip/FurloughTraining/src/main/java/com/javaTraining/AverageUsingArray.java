package com.javaTraining;

public class AverageUsingArray {

	public static void main(String[] args) {
		int[] val={10,20,30,40,50};
		int sum=0;
		for(int i=0;i<val.length;i++)
		{
			sum=sum+val[i];
		}
		System.out.println("Sum is : "+sum);
		System.out.println("Average is  "+sum/val.length);
		

	}

}
