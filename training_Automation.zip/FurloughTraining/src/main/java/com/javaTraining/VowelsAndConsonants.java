package com.javaTraining;

public class VowelsAndConsonants {

	// Count the Number of Vowels and Consonants in a Sentence
	//A, E, I, O, U 
	//Z, B, T, G, H
	//static int count=0;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="welcome to java z";
		vowels(s);
		Consonants(s);
		//System.out.println();
	}
	
	public static void vowels(String s)
	{
		int count =0;
		for(int i=0;i<s.length();i++)
		{
			switch (s.charAt(i)) {
				case 'a':count++;				
					break;
				case 'e':count++;				
					break;
				case 'i':count++;				
					break;
				case 'o':count++;				
					break;
				case 'u':count++;				
					break;

			default:
				break;
			}
		}
		System.out.println("Number of vowels :" +count );
	}
	
	public static void Consonants(String s)
	{
		int count =0;
		for(int i=0;i<s.length();i++)
		{
			switch (s.charAt(i)) {

			case 'z':count++;				
				break;
			case 'b':count++;				
				break;
			case 't':count++;				
				break;
			case 'g':count++;				
				break;
			case 'h':count++;				
				break;
			default:
				break;
			}
		}
		System.out.println("Number of Consonants :" +count );
	}
	
	

}
