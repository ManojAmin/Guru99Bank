package com.javaTraining;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class JoinTwoList {

	public static void main(String[] args) {
		List<Integer> l1=Arrays.asList(1,2,3);
		List<Integer> l2=Arrays.asList(4,5,6);
		List<Integer> l3= new ArrayList<Integer>();
		List<Integer> l4= new ArrayList<Integer>();
		System.out.println(l1);
		System.out.println(l2);
		
		for(int j=0;j<l1.size();j++)
		{
			l3.add(l1.get(j));
		}
		for(int i=0;i<l2.size();i++)
		{
			l3.add(l2.get(i));
			
		}
		System.out.println("After Join : " +l3);
		
		l4.addAll(l1);
		l4.addAll(l2);
		System.out.println("After Join : " +l4);
		

	}

}

