package com.javaTraining;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MapToList {

	public static void main(String[] args) {
		Map<Integer, String> m = new HashMap<Integer, String>();
        m.put(1, "a");
        m.put(2, "b");
        m.put(3, "c");
        m.put(4, "d");
        m.put(5, "e");
        
        List<Integer> l1= new ArrayList<Integer>(m.keySet());
        List<String> l2= new ArrayList<String>(m.values());
        System.out.println(l1);
        System.out.println(l2);

	}

}
