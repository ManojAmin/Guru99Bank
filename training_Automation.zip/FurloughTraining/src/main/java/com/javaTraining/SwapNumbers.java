package com.javaTraining;

public class SwapNumbers {

	public static void main(String[] args) {
		int n1=1,n2=2,n3;
		
		n3=n2;
		n2=n1;
		n1=n3;
		
		System.out.println(n1+" " +n2);
		
		int a1=1,a2=2,a3;
		
		a1=a1+a2;
		a2=a1-a2;
		a1=a1-a2;
		System.out.println(a1+ " "+a2);

	}

}
