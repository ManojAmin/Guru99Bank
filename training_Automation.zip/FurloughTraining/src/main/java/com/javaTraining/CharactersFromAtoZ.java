package com.javaTraining;

public class CharactersFromAtoZ {

	public static void main(String[] args) {
		char s='Z';
		System.out.println((int)s);
		
		System.out.println("Print form A to Z ");
		for(int i=65;i<=90;i++)
		{
			System.out.println((char)i);
		}
		
		System.out.println((char)122);

	}

}
