package com.javaTraining;

import java.util.Scanner;

public class MultiplicationTable {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter table vlaue");
		int n1=s.nextInt();
		System.out.println("enter table vlaue till");
		int n2=s.nextInt();
		
		for(int i=1;i<=n2;i++)
		{
			System.out.println(n1+ " * " +i+ " = " +n1*i);
		}
	}

}
