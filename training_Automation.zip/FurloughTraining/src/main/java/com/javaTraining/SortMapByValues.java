package com.javaTraining;

import java.util.HashMap;
import java.util.Map;

public class SortMapByValues {

	public static void main(String[] args) {
		Map<Integer, String> m = new HashMap<Integer, String>();
        m.put(1, "d");
        m.put(2, "c");
        m.put(3, "e");
        m.put(4, "a");
        m.put(5, "b");
System.out.println(m);
	}
}
