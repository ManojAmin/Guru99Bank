package com.javaTraining;

import java.util.HashMap;
import java.util.Map;

public class FrequencyOfCharacter {

	public static void main(String[] args) {
		String s="aa bb cc d e fff %";
		Map<Character,Integer> m=new HashMap<Character,Integer>();
		
		for(int i=0;i<s.length();i++)
		{
			if(m.containsKey(s.charAt(i)))
			{
				int count=m.get(s.charAt(i));
				m.put(s.charAt(i), count+1);
			}
			else
			{
				m.put(s.charAt(i), 1);
			}
		}
		
		System.out.println(m);

	}

}
