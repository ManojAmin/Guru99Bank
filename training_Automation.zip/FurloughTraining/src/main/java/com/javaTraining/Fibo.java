package com.javaTraining;

public class Fibo {

	public static int f1=0,f2=1,f3;
	public static void main(String[] args) {	
		int n=8;
		System.out.println("fibonacci series are : " +f1);
		System.out.println(f2);
		fib(n-2);
	}
	public static void fib(int n)
	{
		if(n>0)
		{
			f3=f1+f2;
			System.out.println(f3);
			f1=f2;
			f2=f3;
			fib(n-1);
		}
	}

}
