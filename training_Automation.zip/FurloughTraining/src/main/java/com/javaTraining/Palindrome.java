package com.javaTraining;

public class Palindrome {

	public static void main(String[] args) {
		String s="aba",rev="";
		
		char s1;
		
		
		for(int i=0;i<s.length();i++)
		{
			s1=s.charAt(i);
			rev=s1+rev;
			
		}
		System.out.println(rev);
		if(s.equalsIgnoreCase(rev))
		{
			System.out.println("String is Palindrome");
		}
		else
		{
			System.out.println("String is not Palindrome");
		}
			
			
	}

}
