package com.javaTraining;

import java.util.ArrayList;
import java.util.List;

public class ListToArray {

	public static void main(String[] args) {
		List<Integer> l1= new ArrayList<Integer>();
		l1.add(1);
		l1.add(2);
		l1.add(3);
		
		Integer[] val=new Integer[l1.size()];
		
		l1.toArray(val);
		
		for (Integer i : val) {
			System.out.println(i);
		}
	}

}
