package com.javaTraining;

public class Patrrerns {

	public static void main(String[] args) {
		//pyramid();
		pattern();
	}
	
	public static void pyramid()
	{
		for(int i=0;i<=4;i++)
		{
			for(int j=4;j<=i;j--)
			{
				System.out.print(" *");
			}
			System.out.println("");
		}
	}
	
	public static void pattern()
	{
		for(int i=0;i<=4;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print(" * ");
			}
			System.out.println("");
		}
	}

}
