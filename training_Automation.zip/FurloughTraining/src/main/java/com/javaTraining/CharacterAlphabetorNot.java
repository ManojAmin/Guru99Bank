package com.javaTraining;

import java.util.Scanner;

public class CharacterAlphabetorNot {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		char i='@';
		
		if(Character.isAlphabetic(i))
		{
			System.out.println("character is aplhabetic");
		}
		else if(Character.isDigit(i))
		{
			System.out.println("character is digit");
		}
		else if(Character.isSpaceChar(i))
		{
			System.out.println("character is space");
		}
		else 
		{
			System.out.println("character is special character");
		}
		

	}

}
