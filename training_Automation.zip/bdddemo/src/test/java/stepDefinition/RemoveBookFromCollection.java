/**
 * 
 */
package stepDefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;

import baseClass.Base;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjectRepository.BookDetailsPAge;
import pageObjectRepository.ProfilePage;
import utilities.Alerts;

public class RemoveBookFromCollection extends Base {
	
	WebDriver driver;
	AddBookToCollectionSD AddSD;; 
	Alerts alert;
	ProfilePage profilePage;
	BookDetailsPAge bookDetails;
	String bookAdded;
	
	@Given("Login to the applcation with valid credential")
	public void login_to_the_applcation_with_valid_credential() {
		AddSD=new AddBookToCollectionSD(); 
		driver=driverInitialization();
		AddSD.loginAndNAvigateTOBookPage(driver);
	}
	@When("Add  book to the colection")
	public void add_book_to_the_colection() {
		AddSD.addBookToTheCollection();
		alert =new Alerts(driver);
		alert.alertAccept(); 		
		logger.info("Clicked OK on alert");
	}
	@Then("remove the book addet to the collection")
	public void remove_the_book_addet_to_the_collection() {
		profilePage=new ProfilePage(driver);
		bookDetails=new BookDetailsPAge(driver);
		
		profilePage.scrollToProfile();
    	profilePage.clickOnProfile();
    	logger.info("navigated to profile page");
    	//wait.waitFor10seconds(); 
    	profilePage.scrollToBookAddedInTheCollection();
    	profilePage.ClickOnDeleteIcon();
    	alert.alertAccept();
    	
    	//driver.close();
	}

}
