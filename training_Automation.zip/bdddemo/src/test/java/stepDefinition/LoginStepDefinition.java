package stepDefinition;

import static junit.framework.Assert.assertEquals;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

import baseClass.Base;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjectRepository.BookStoreHome;
import pageObjectRepository.HomePage;
import pageObjectRepository.LoginPage;
import pageObjectRepository.ProfilePage;
import utilities.LoginUtils;
import utilities.Scrolling;

public class LoginStepDefinition extends Base {

	WebDriver driver;
	LoginUtils login;
	ProfilePage profilePage;

	@Given("^Enter the URL and navigate to login page$")
	public void enter_the_url_and_navigate_to_login_page() {
		driver = driverInitialization();
		login=new LoginUtils(driver);
		login.navigateToLoginPage();
	}	

	@When("^provide username and password and login$")
	public void provide_username_and_password_and_login() {

		String userName=username();
		String password=password();
		login.enterCredentialAndLogin(userName, password,driver);

	}	
	
	@When("Enter {string} and password {string}")
	public void enter_and_password(String userName, String password) {
		
		logger.debug("user name : " + userName);
		logger.debug("password: " + password);
		login.enterCredentialAndLogin(userName, password,driver);
	}

	@Then("^verify user logged in successfully$")
	public void verify_user_logged_in_successfully() {
		profilePage=new ProfilePage(driver);
		if (login.isValidCredintial()) {
			String username = profilePage.getLoggedInUserNameOnProfilePage();
			logger.info("Valid User name or password ");
			logger.debug("logged in user name on profile page : " + username);
			assertEquals(username(), username);
		} else {
			logger.info("Invalid User name or password ");
		}
		driver.close();
	}	
	

	/*public void navigateToLoginPage() {
		homepage = new HomePage(driver);
		scroll = new Scrolling(driver);
		bookStoreHome = new BookStoreHome(driver);

		scroll.scrollToBottom();
		homepage.clickOnBookStoreApplication();
		scroll.scrollToBottom();
		bookStoreHome.ClickOnLoginInMenuList();
		logger.info("clicked on login in menu list");
	} */
	
/*	public void enterCredentialAndLogin(String userName, String password) {
		loginpage = new LoginPage(driver);
		loginpage.enterUserName(userName);
		logger.info("User name entered");
		loginpage.enterPassword(password);
		logger.info("password entered");
		profilePage = loginpage.clickonLogin();
		logger.info("clicked on login button");
	} */
	
	/*public boolean isValidCredintial() {
		try {
			loginpage.invalidCredintialMessage();
			return false;
		} catch (NoSuchElementException e) {
			return true;
		}
	} */
}
