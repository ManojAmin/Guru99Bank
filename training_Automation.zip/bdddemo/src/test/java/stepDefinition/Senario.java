package stepDefinition;

import org.junit.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Senario {

	@Given("Launch the browser and enter the URL")
	public void launch_the_browser_and_enter_the_url() {
		System.out.println("Browser launched successfully");
	}
	
	@When("user enters valid {string} and {string}")
	public void user_enters_valid_and(String string, String string2) {
		System.out.println("user enters valid user name and password entered");
	}
	
	@When("clicks login button")
	public void clicks_login_button() {
		System.out.println("Clicked on login buttoon");
	}
	
	@Then("verify user logged in successfully and navigate to the home page")
	public void verify_user_logged_in_successfully_and_navigate_to_the_home_page() {
		System.out.println("user logged in successfully and navigate to the home page");
	}
	
	@When("user enters invalid {string} and {string}")
	public void user_enters_invalid_and(String string, String string2) {
		System.out.println("user enters invalid user name and password entered");
	}
	
	@Then("verify user not logged in successfully and shown with error message")
	public void verify_user_not_logged_in_successfully_and_shown_with_error_message() {
		System.out.println("user not logged in successfully and shown with error message");
	}
	
	@When("user enters valid Value-{int} and Value-{int}")
	public void user_enters_valid_value_and_value(Integer int1, Integer int2) {
		System.out.println("user enters valid user name and password entered");
	}
	
	@When("user login in with valid credentials")
	public void user_login_in_with_valid_credentials() {
		System.out.println("user login in with valid credentials");
	}
	
	@Then("Navigate to the account summary page")
	public void navigate_to_the_account_summary_page() {
		System.out.println("user Navigate to the account summary page");
	}
	
	@Then("Check the account balance is zero in the account summary page")
	public void check_the_account_balance_is_zero_in_the_account_summary_page() {
		System.out.println("Checking the account balance is zero in the account summary page");
	}
	
	@Then("user tries to pay when account balance is zero")
	public void user_tries_to_pay_when_account_balance_is_zero() {
		System.out.println("user tries to pay when account balance is zero");
	}
	
	@Then("transaction should not be initiated and error message {string} should be displayed")
	public void transaction_should_not_be_initiated_and_error_message_should_be_displayed(String string) {
	    Assert.assertEquals("Account balance is zero", string);
	}
	
	@Then("Account balance should not be updated")
	public void account_balance_should_not_be_updated() {
		System.out.println("Account balance is not updated");
	}
	
	@Then("Check the account balance is not zero in the account balance page")
	public void check_the_account_balance_is_not_zero_in_the_account_balance_page() {
		System.out.println("Checking the account balance is not zero in the account balance page");
	}
	
	@Then("user tries to do online transaction when user has sufficient balance")
	public void user_tries_to_do_online_transaction_when_user_has_sufficient_balance() {
		System.out.println("user tries to do online transaction when user has sufficient balance");
	}
	
	@Then("transaction should be initiated and success message should be displayed")
	public void transaction_should_be_initiated_and_success_message_should_be_displayed() {
		System.out.println("transaction should be initiated and success message should be displayed");
	}
	
	@Then("Account balance should be updated")
	public void account_balance_should_be_updated() {
		System.out.println("Account balance  updated");
	}
	
	@Then("Check the account balance is insufficient in the account balance page")
	public void check_the_account_balance_is_insufficient_in_the_account_balance_page() {
		System.out.println("Checking the account balance is insufficient in the account balance page");
	}
	
	@Then("user tries to do online transaction when user has insufficient balance")
	public void user_tries_to_do_online_transaction_when_user_has_insufficient_balance() {
		System.out.println("user tries to do online transaction when user has insufficient balance");
	}
	
	@Then("Check the account balance is negative in the account summary page")
	public void check_the_account_balance_is_negative_in_the_account_summary_page() {
		System.out.println("Check the account balance is negative in the account summary page");
	}
}
