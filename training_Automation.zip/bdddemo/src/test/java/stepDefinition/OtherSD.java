package stepDefinition;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class OtherSD {
	

@Given("login to the applcation")
public void login_to_the_applcation() {
}
@When("enter amount for transaction")
public void enter_amount_for_transaction() {
	
}

@Then("user should get account balance is zero message")
public void user_should_get_account_balance_is_zero_message() {
	
}

@Then("user should get credited amount is larger than account balance message")
public void user_should_get_credited_amount_is_larger_than_account_balance_message() {
	
}

@Then("amount shoud be transfered and credited from the the account")
public void amount_shoud_be_transfered_and_credited_from_the_the_account() {
	
}

@Given("login into the applcation using usename {string} and password {string}")
public void login_into_the_applcation_using_usename_and_password(String string, String string2) {
	
}


}
