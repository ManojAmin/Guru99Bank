package stepDefinition;

import static utilities.ConstantText.alertMessageWhileAddingBookTwice;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import baseClass.Base;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjectRepository.BookDetailsPAge;
import pageObjectRepository.BookStoreHome;
import pageObjectRepository.BookStorePage;
import pageObjectRepository.HomePage;
import pageObjectRepository.LoginPage;
import pageObjectRepository.ProfilePage;
import utilities.Alerts;
import utilities.ConstantText;
import utilities.LoginUtils;
import utilities.Scrolling;
import utilities.Waiting;

public class AddBookToCollectionSD extends Base{
	
	WebDriver driver;
	LoginUtils login;
	HomePage homepage;
	Scrolling scroll;
	BookStoreHome bookStoreHome;
	LoginPage loginpage;
	ProfilePage profilePage;	
	BookStorePage bookstore;
	BookDetailsPAge bookDetails;
	Waiting wait;
	Alerts alert;
	String bookSelected;
	String bookAdded;
   
	@Given("^Login into the application and navigate to book store page$")
    public void loginIntoTheApplicationAndNavigateToBookStorePage() {
		
		driver = driverInitialization();
		loginAndNAvigateTOBookPage(driver);
		
    }

    @When("^select a book and add to the collection$")
    public void addBookToTheCollection() {
    	bookstore=new BookStorePage(driver);
    	scroll =new Scrolling(driver);
    	bookstore.scrollTillFirstBookInTheList();
    	//wait.waitFor10seconds();   
    	bookSelected=bookstore.selectFirstBook();
    	logger.debug("Book selected is :" +bookSelected); 
    	logger.info("Book is selected"); 
    	//wait.waitFor10seconds(); 
    	//bookstore.scrollTillAddToCollectionButton();
    	scroll.scrollToBottom();
    	logger.info("Scrooled down to click on Add to collection button");
    	
    	bookstore.clickAddToCollection();
    	logger.info("Clikced on Add to collection button");
    	
    }

    @Then("^go the porfile and check whether book added to collection or not$")
    public void go_the_porfile_and_check_whether_book_added_to_collection_or_not() {
    	bookDetails=new BookDetailsPAge(driver);
    	
		alert.alertAccept(); 		
		logger.info("Clicked OK on alert");
		
    	profilePage.scrollToProfile();
    	profilePage.clickOnProfile();
    	logger.info("navigated to profile page");
    	//wait.waitFor10seconds(); 
    	profilePage.scrollToBookAddedInTheCollection();
    	profilePage.clickOnBookName();
    	logger.info("Clicked on book name ");
    	bookAdded=bookDetails.getBookTitle();
    	logger.info("book name in the collection: "+bookAdded);		
    	Assert.assertEquals(bookSelected, bookAdded);
    	driver.close();
		
    }
    
    @Then("user should get book adrealy added alert message")
    public void bookAlreadyAddedVerification() {
    	
    	String alertMessage=alert.getAlertMessage();
    	logger.debug("Alert message :"+alertMessage);
    	Assert.assertEquals(alertMessageWhileAddingBookTwice, alertMessage);
    	alert.alertAccept();
    	driver.close();
    }
    
    
    public void loginAndNAvigateTOBookPage(WebDriver driver) {
		login=new LoginUtils(driver);
		profilePage=new ProfilePage(driver);
		wait=new Waiting(driver);
		alert = new Alerts(driver);
		
		login.navigateToLoginPage();
		String userName=username();
		logger.debug("User name is:" +userName);		
		String password=password();
		logger.debug("Password is:" +password);
		login.enterCredentialAndLogin(userName, password,driver);
		
    	//wait.waitFor10seconds();    	
    	profilePage.scrollDown();
    	logger.info("scrolled down to book store button in login page");
    	profilePage.clickonGotoBookStore();
    	logger.info("navigated to book store page");
	}

}
