package utilities;

import org.apache.log4j.Logger;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

import pageObjectRepository.BookStoreHome;
import pageObjectRepository.HomePage;
import pageObjectRepository.LoginPage;
import pageObjectRepository.ProfilePage;

public class LoginUtils {

	public static Logger logger=Logger.getLogger("BDDFrameWork");
	WebDriver driver;
	HomePage homepage;
	Scrolling scroll;
	BookStoreHome bookStoreHome;
	LoginPage loginpage;
	ProfilePage profilePage;

	public LoginUtils(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public void navigateToLoginPage() {
		homepage = new HomePage(driver);
		scroll = new Scrolling(driver);
		bookStoreHome = new BookStoreHome(driver);

		scroll.scrollToBottom();
		homepage.clickOnBookStoreApplication();
		scroll.scrollToBottom();
		bookStoreHome.ClickOnLoginInMenuList();
		logger.info("clicked on login in menu list");
	}
	
	public void enterCredentialAndLogin(String userName, String password,WebDriver driver) {
		loginpage = new LoginPage(driver);
		loginpage.enterUserName(userName);
		logger.info("User name entered");
		loginpage.enterPassword(password);
		logger.info("password entered");
		profilePage = loginpage.clickonLogin();
		logger.info("clicked on login button");
	}
	
	public boolean isValidCredintial() {
		try {
			loginpage.invalidCredintialMessage();
			return false;
		} catch (NoSuchElementException e) {
			return true;
		}
	}
}
