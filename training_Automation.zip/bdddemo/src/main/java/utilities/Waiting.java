package utilities;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;

public class Waiting {

	WebDriver driver;

	public Waiting(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public void waitFor10seconds()
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

}
