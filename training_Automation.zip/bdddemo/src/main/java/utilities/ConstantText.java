package utilities;

public class ConstantText {

	public final static String ProfilePageTitle="Profile";
	public final static String alertMessageWhileAddingBookTwice="Book already present in the your collection!";
}
