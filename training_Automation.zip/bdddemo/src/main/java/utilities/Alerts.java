package utilities;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Alerts {
	public static Logger logger=Logger.getLogger("BDDFramework");
	WebDriver driver;
	WebDriverWait wait1;
	
	public Alerts(WebDriver driver) {
		super();
		this.driver = driver;
		wait1= new WebDriverWait(driver,10);
	}

	public void alertAccept()
	{		
		try
		{
			Alert alert=wait1.until(ExpectedConditions.alertIsPresent());
			logger.debug("Alert is :"+alert);
			if(alert!=null)
			{
				logger.info("alert Present");
				alert.accept();
			}
			else
			{
				logger.info("alert Present");
			}
		}
		catch (NoAlertPresentException e) {
			logger.debug("AlertException: "+e);
		}		
	}
	
	public String getAlertMessage()
	{
		Alert alert=wait1.until(ExpectedConditions.alertIsPresent());
		logger.debug("Alert is :"+alert);
		if(alert!=null)
		{
			logger.info("alert Present");
			return driver.switchTo().alert().getText();
		}
		else
		{
			logger.info("alert Present");
			return "error";
		}
		
	}
}
