package pageObjectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BookStoreHome {
	
	WebDriver driver;

	public BookStoreHome(WebDriver driver) {
		super();
		this.driver = driver;
	}
	

	By loginInMenuList=By.xpath("//ul[@class='menu-list']//span[text()='Login']");
	
	public void ClickOnLoginInMenuList()
	{
		driver.findElement(loginInMenuList).click();
	}
}
