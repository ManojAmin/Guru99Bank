package pageObjectRepository;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utilities.BaseURLUtility;

public class LoginPage {

	WebDriver driver;
	
	public static Logger logger=Logger.getLogger("BDDFrameWork");

	public LoginPage(WebDriver driver) {
		super();
		logger.info("in LoginPage ");
		this.driver = driver;
		
	}
	
	By userName=By.id("userName");
	By password=By.id("password");
	By loginButton=By.id("login");
	By invalidCredintial=By.id("name");
	
	public void enterUserName(String uname)
	{
		driver.findElement(userName).sendKeys(uname);
	}
	
	public void enterPassword(String pwd) 
	{
		driver.findElement(password).sendKeys(pwd);
	}
	
	public ProfilePage clickonLogin()
	{
		driver.findElement(loginButton).click();
		
		return new ProfilePage(driver);
	}
	
	public boolean invalidCredintialMessage()
	{
		return driver.findElement(invalidCredintial).isDisplayed();
	}
	
}
