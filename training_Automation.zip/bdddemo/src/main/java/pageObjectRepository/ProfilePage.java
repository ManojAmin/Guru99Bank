package pageObjectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;

import utilities.Scrolling;

import org.apache.log4j.Logger;

public class ProfilePage {
	
	public static Logger logger=Logger.getLogger("BDDFrameWork");
	WebDriver driver;
	Scrolling scroll;
	
	public ProfilePage(WebDriver driver) {
		super();
		this.driver = driver;
	}	
	
	By loggedInUserNameOnProfilePage=By.id("userName-value");
	By gotoStore=By.id("gotoStore");
	By profile=By.xpath("//ul[@class='menu-list'] //span[text()='Profile']");
	By bookAddedToTheCollection=By.xpath("(//*[contains(@id, 'see-book')])[1]");
	By bookDeleteIcon=By.id("//span[@id='delete-record-undefined']");
	By okButtonOnModal=By.id("closeSmallModal-ok");
	
	
	public String getLoggedInUserNameOnProfilePage()
	{
		return driver.findElement(loggedInUserNameOnProfilePage).getText();
	}
	
	
	public void clickonGotoBookStore()
	{
		driver.findElement(gotoStore).click();
	}
	
	public void clickOnProfile()
	{
		driver.findElement(profile).click();
	}
	
	public String getBookAddedToTheCollection()
	{
		return driver.findElement(bookAddedToTheCollection).getText();
	}
	public void clickOnBookName()
	{
		Actions a=new Actions(driver);
		a.moveToElement(driver.findElement(bookAddedToTheCollection)).click().build().perform();
		//return driver.findElement(bookAddedToTheCollection).getText();
	}
	
	public void ClickOnDeleteIcon()
	{
		driver.findElement(bookDeleteIcon).click();
	}
	
	public void clickOnOKInModal()
	{
		driver.findElement(okButtonOnModal).click();
	}
	
	
	public void scrollToBookAddedInTheCollection()
	{
		scroll=new Scrolling(driver);
		scroll.scrollIntoView(bookAddedToTheCollection);
	}
	
	public void scrollDown()
	{
		scroll=new Scrolling(driver);
		scroll.scrollIntoView(gotoStore);
	}
	
	public void scrollToProfile()
	{
		scroll=new Scrolling(driver);
		scroll.scrollIntoView(profile);
	}
	
	
}
