package pageObjectRepository;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import utilities.Scrolling;

public class BookStorePage {
	WebDriver driver;
	Scrolling scroll;

	public BookStorePage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	By firstBookInTheList=By.xpath("(//*[contains(@id, 'see-book')])[1]");
	By addToCollection=By.xpath("//button[text()='Add To Your Collection']");
	
	
	public String selectFirstBook()
	{
		String bookName=driver.findElement(firstBookInTheList).getText();
		driver.findElement(firstBookInTheList).click();
		
		return bookName;
	}
	
	
	public void clickAddToCollection()
	{
		/*
		 * WebDriverWait wait =new WebDriverWait(driver,20);
		 * 
		 * wait.until(ExpectedConditions.elementToBeClickable(addToCollection));
		 */
		
		Actions a=new Actions(driver);
		a.moveToElement(driver.findElement(addToCollection)).click().build().perform();
		//driver.findElement(addToCollection).click();
	}
	
	public void scrollTillAddToCollectionButton()
	{
		scroll=new Scrolling(driver);
		scroll.scrollIntoView(addToCollection);
	}
	
	public void scrollTillFirstBookInTheList()
	{
		scroll=new Scrolling(driver);
		scroll.scrollIntoView(firstBookInTheList);
	}
	
	

}
