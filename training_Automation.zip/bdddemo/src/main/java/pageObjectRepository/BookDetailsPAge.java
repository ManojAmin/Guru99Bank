package pageObjectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class BookDetailsPAge {

	WebDriver driver;

	public BookDetailsPAge(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	By bookTitle=By.xpath("(//label[@id='userName-value'])[2]");
	
	
	public String getBookTitle()
	{
		return driver.findElement(bookTitle).getText();
	}
}

