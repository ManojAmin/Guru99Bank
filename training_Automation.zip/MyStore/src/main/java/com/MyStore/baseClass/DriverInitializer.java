package com.MyStore.baseClass;

import static java.util.concurrent.TimeUnit.SECONDS;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;

import com.MyStore.utilities.ApplicationConfigUtility;

import io.github.bonigarcia.wdm.WebDriverManager;

public class DriverInitializer {
	ChromeOptions co;
	WebDriver driver;
	ApplicationConfigUtility appConfigUtil;
	
	public WebDriver initializeDriver()
	{
		co=new ChromeOptions();
		appConfigUtil =new ApplicationConfigUtility();
		co.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
		co.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, SECONDS);
		driver.get(appConfigUtil.getURL());	
		return driver;
	}
	
	

}
