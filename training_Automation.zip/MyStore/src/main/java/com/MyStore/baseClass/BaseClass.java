package com.MyStore.baseClass;

import org.openqa.selenium.WebDriver;

public class BaseClass {
	
	public WebDriver driver;

}
