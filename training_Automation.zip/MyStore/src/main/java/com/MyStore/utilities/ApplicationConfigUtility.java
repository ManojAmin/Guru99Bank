package com.MyStore.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ApplicationConfigUtility {
	FileInputStream readFile;
	Properties prop;
	
	
	public ApplicationConfigUtility() {
		try {
			readFile=new FileInputStream("C:\\Automation\\MyStore\\src\\test\\resources\\application-Config.properties");
			prop=new Properties();
			prop.load(readFile);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String getURL()
	{
		return prop.getProperty("url");
	}
}
