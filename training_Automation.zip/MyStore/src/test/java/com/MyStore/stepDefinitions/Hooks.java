package com.MyStore.stepDefinitions;

import org.openqa.selenium.chrome.ChromeDriver;

import com.MyStore.baseClass.BaseClass;
import com.MyStore.baseClass.DriverInitializer;

import io.cucumber.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Hooks extends BaseClass{

	private BaseClass base;
	DriverInitializer launchBrowser;
	
	public Hooks(BaseClass base) {
		super();
		this.base = base;
	}
	
	@Before
	public void setUp()
	{
		launchBrowser=new DriverInitializer();
		//WebDriverManager.chromedriver().setup();
		//driver = new ChromeDriver();
		base.driver=launchBrowser.initializeDriver();
		
	}
}
