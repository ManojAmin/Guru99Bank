package com.MyStore.stepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.MyStore.baseClass.BaseClass;
import com.MyStore.baseClass.DriverInitializer;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SampleStepDef extends BaseClass{
	
	
	private BaseClass base;
	public SampleStepDef(BaseClass base) {
		this.base = base;
	}

	@Given("enter url")
	public void enter_url() {
	//	driver=initializeDriver();
		System.out.println("in Given");		
		base.driver.findElement(By.id("search_query_top")).sendKeys("shirt");
		base.driver.findElement(By.name("submit_search")).click();
	}
	
	@When("go to home")
	public void go_to_home() {
		
	}
	
	@Then("chek the page")
	public void chek_the_page() {
		
	}

}
