package com.Automation;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ReadWebTable {
	WebDriver driver;

	public ReadWebTable(WebDriver driver) {
		super();
		this.driver = driver;
	}

	private Map<String, Map<String, String>> storeData() {

		List<WebElement> ele=driver.findElements(By.xpath("//div[@class='rt-tr-group']"));
		Map<String, Map<String, String>> tableMap = new HashMap<String, Map<String, String>>();

		Map<String, String> dataMap = new HashMap<String, String>();

		for (int i = 1; i < ele.size(); i++) {
			String key = driver.findElement(By.xpath("//div[@class='rt-tr-group']["+i+"]/div/div[1]")).getText();
			String value = driver.findElement(By.xpath("//div[@class='rt-tr-group']["+i+"]/div/div[5]")).getText();
			dataMap.put(key, value);
			tableMap.put("DataSheet", dataMap);
		}

		return tableMap;
	}

	public String getMapData(String key) throws IOException {

		Map<String, String> m = storeData().get("DataSheet");
		String value = m.get(key);

		return value;

	}

}
