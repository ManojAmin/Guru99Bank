package com.Automation;

import java.util.ArrayList;

public class Sample {

	 public static void main( String[] args )
	    {        

			ArrayList l=new ArrayList();
			
			l.add(123);
			l.add("abc");
			l.add(567);
			l.add(true);
			
			for (Object object : l) {
				System.out.println(object);
			}
		
	    }
	
	
	
}
