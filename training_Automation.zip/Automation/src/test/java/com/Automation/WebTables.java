package com.Automation;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class WebTables {

	private static final String OUTPUTTYPE = null;

	@Test(enabled = false)
	public void webTablesEg1()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.guru99.com/test/web-table-element.php");
		driver.manage().window().maximize();
		//List<WebElement> ele=driver.findElements(By.xpath("//div[@class='rt-tr-group']"));
		//List<WebElement> ele=driver.findElements(By.xpath("//table[@class='dataTable']/tbody/tr"));
		List<WebElement> ele=driver.findElements(By.xpath("//table[@class='dataTable']/tbody/tr/td[1]"));
		System.out.println(ele.size());
		for (WebElement e : ele) {
			System.out.println(e.getText());
		}
	}
	
	
	@Test(enabled = false)
	public void webTablesEg2() throws IOException
	{		
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/webtables");
		driver.manage().window().maximize();		
		ReadWebTable values= new ReadWebTable(driver);		
		String fname="Kierra";
		String val =values.getMapData(fname);
		
		//Select v=new Select(driver.findElement(By.id("m")));
		
		System.out.println("salary of ("+fname+") is : "+val);	
	}
	
	@Test
	public void webTablesEg3() throws IOException
	{		
				
		ReadExcelSheetData values= new ReadExcelSheetData();		
		String fname="search1";
		String val =ReadExcelSheetData.getMapData(fname);
		
		System.out.println("values of key ("+fname+") is : "+val);	
		
		ArrayList<Integer> n=new ArrayList<Integer>();
	}
	
	@Test(enabled = false)
	public void webTablesEg4() throws IOException
	{		
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/webtables");
		driver.manage().window().maximize();		
		
		TakesScreenshot s=((TakesScreenshot)driver);
		s.getScreenshotAs(OutputType.FILE);
		
	}
}
