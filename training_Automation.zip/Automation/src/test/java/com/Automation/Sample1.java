package com.Automation;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Sample1 {
	
	@Test
	public void demo()
	{
		//1).W A Selenium program to handle page load
		/*2).W A Selenium program to handle the window popup or alert or frame or new browser tab and click on Ok button .
		 Start from initializing the browser till closing the popup */
		
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
		// handling page load
		driver.manage().timeouts().pageLoadTimeout(50, TimeUnit.SECONDS);
		driver.get("https://demoqa.com/browser-windows");
		
		String current_window=driver.getWindowHandle();
		driver.findElement(By.id("windowButton")).click();
		
		//Window popup
		Set<String> windows=driver.getWindowHandles();
		
		for (String window: windows) {
			if(current_window.equals(window))
			{
				System.out.println(window +":"+driver.getCurrentUrl());				
			}
			else
			{
				driver.switchTo().window(window);
				System.out.println(window +":"+driver.getCurrentUrl());
				driver.close();
			}
		}
		driver.switchTo().window(current_window);
		driver.getWindowHandle();
		System.out.println(driver.getTitle());
		
		//driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		JavascriptExecutor js=((JavascriptExecutor)driver);
		js.executeScript("window.scrollBy(0,500)");
		
		driver.findElement(By.xpath("//span[text()='Alerts']")).click();
		
		//alert handling
		driver.findElement(By.id("alertButton")).click();
		driver.switchTo().alert().accept();
		driver.findElement(By.id("confirmButton")).click();
		driver.switchTo().alert().dismiss();
		
		//Select s=new Select(driver.findElement(By.id("alertButton")));
		
		
	}
	
	@Test(enabled = false)
	public void demo1()
	{
		//3).W A Selenium method to check whether the field is editable or not before entering the data to the text field
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver.get("file:///C:/Automation/sample.html");
		WebElement ele=driver.findElement(By.id("myText"));
		
		if(ele.isEnabled())
		{
			System.out.println("Enabled");
		}
		else
		{
			System.out.println("disabled");
		}
		
		driver.findElement(By.id("but1")).click();
		
		System.out.println("After clicking on button");
		
		if(ele.isEnabled())
		{
			System.out.println("Enabled");
		}
		else
		{
			System.out.println("disabled");
		}
	}

}
