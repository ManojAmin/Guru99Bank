package com.Automation;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Assesment_08_march {

	@Test
	public void countOfCheckedAndUncheckedCheckBoxes()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\driver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
				
		driver.manage().window().maximize();
		driver.get("file:///C:/Automation/sample.html");
		
		List<WebElement> ele=driver.findElements(By.xpath("//input[@type='checkbox']"));
		int checked=0,unchecked=0;
		
		for (WebElement e : ele) {
			
			
			if(e.isSelected())
			{
				checked++;
			}
			else
			{
				unchecked++;
			}
		}		
		System.out.println("Number of checked check boxes : " +checked);
		System.out.println("Number of Unchecked check boxes : " +unchecked);
				
		
		
	}
	
	@Test(enabled = false)
	public void readDataFromProperyFile()
	{
		Properties pro=new Properties();		
		try {
			FileInputStream file=new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\resourses\\data.properties");			
			pro.load(file);
			
			String name=pro.getProperty("name");
			String address=pro.getProperty("address");
			System.out.println(name);
			System.out.println(address);
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}
}
