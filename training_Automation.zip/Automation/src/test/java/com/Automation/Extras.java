package com.Automation;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.UnexpectedAlertBehaviour;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Extras {
	
	@Test
	public void sam()
	{
		//DesiredCapabilities dc = new DesiredCapabilities();
		//dc.setCapability(CapabilityType.UNEXPECTED_ALERT_BEHAVIOUR, UnexpectedAlertBehaviour.IGNORE);
		ChromeOptions co=new ChromeOptions();
		co.addArguments("--incognito");
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\driver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver(co);
		driver.manage().window().maximize();
		JavascriptExecutor j=(JavascriptExecutor)driver;
		driver.get("https://demoqa.com");				
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		j.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		driver.findElement(By.xpath("//h5[contains(text(),'Book Store Application')]")).click();
		j.executeScript("window.scrollTo(0, document.body.scrollHeight)");
		driver.findElement(By.xpath("//ul[@class='menu-list']//span[text()='Login']")).click();
		driver.findElement(By.id("userName")).sendKeys("manoj");
		driver.findElement(By.id("password")).sendKeys("Manoj@123");
		driver.findElement(By.id("login")).click();
		
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.id("gotoStore")));
		driver.findElement(By.id("gotoStore")).click();
		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("(//*[contains(@id, 'see-book')])[1]")));
		driver.findElement(By.xpath("(//*[contains(@id, 'see-book')])[1]")).click();
		
		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath("//button[text()='Add To Your Collection']")));
		driver.findElement(By.xpath("//button[text()='Add To Your Collection']")).click();
		
		WebDriverWait wait1= new WebDriverWait(driver,10);
		Alert a=wait1.until(ExpectedConditions.alertIsPresent());
		if(a==null)
		{
			System.out.println("alert not present");
		}
		else
		{
			System.out.println("alert present");
		}
		driver.switchTo().alert().accept();

	}
}
