package com.Automation;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class ModalDialog {

	@Test(enabled = false)
	public void handleSmallModalDialogue()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/modal-dialogs");
		driver.manage().window().maximize();
		
		driver.findElement(By.id("showSmallModal")).click();
		String text=driver.findElement(By.xpath("//div[@class='modal-body']")).getText();
		
		System.out.println("modal Body is :" +text);
		
		driver.findElement(By.id("closeSmallModal")).click();
	}
	
	@Test
	public void handleLargeModalDialogue()
	{
		
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/modal-dialogs");
		driver.manage().window().maximize();
		
		driver.findElement(By.id("showLargeModal")).click();
		
		String text=driver.findElement(By.xpath("//div[@class='modal-body']/p")).getText();
		
		System.out.println(text);
		
		driver.findElement(By.id("closeLargeModal")).click();
	}
}
