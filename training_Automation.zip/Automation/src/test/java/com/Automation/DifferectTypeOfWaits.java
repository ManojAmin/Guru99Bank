package com.Automation;

import java.time.Duration;
import java.util.NoSuchElementException;
import java.util.function.Function;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class DifferectTypeOfWaits {

	@Test(enabled = false)
	public void threadSleep() throws InterruptedException
	{
		//Thread.sleep is a java wait which pause the current thread exucution for some so that remaining line of code will no executed for the given time
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		Thread.sleep(10000);
		driver.findElement(By.name("q")).sendKeys("ind");
	}
	
	@Test(enabled = false)
	public void implecitWait() throws InterruptedException
	{
		//The Implicit Wait tells the web driver to wait for a certain amount of time before it throws a No Such Element Exception.
		//It is a global wait and applied to all elements on the webpage.
		
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		//driver.findElement(By.id("twotabsearchtextbox")).sendKeys("mobile");
		driver.findElement(By.xpath("//div[@id=\"nav-signin-tooltip\"] //span[contains(text(),'Sign in')]")).click();
	}
	
	@Test(enabled = false)
	public void explicitWait() throws InterruptedException
	{
		//explicit wait will be applied only to the particular element.
		//if the particular element is taken more time at that time explicit wait will be applied on that element to wait for some time before throwing the exception.
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.amazon.in/");
		
		WebDriverWait wait=new WebDriverWait(driver, Duration.ofSeconds(10));
		
		WebElement ele=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@id=\"nav-signin-tooltip\"] //span[contains(text(),'Sign in')]")));
		
		ele.click();		
		
	}
	
	@Test
	public void fluentWait() throws InterruptedException
	{
		/*both webDriverWait and FluentWait are applied on the particulars.
		but the only difference is in FluentWait we provide pooling time.if we provide pooling time as 3
		then element will be checked for 3rd second if element is still not present then it will be checked a 6th second.
		here element will not be check for each second .depending on the polling time element will be checked here. */
		
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/dynamic_loading/1");
		driver.findElement(By.xpath("//div[@id=\"start\"]/button")).click();
		
		
		
		Wait wait=new FluentWait(driver)
				.withTimeout(Duration.ofSeconds(10))
				.pollingEvery(Duration.ofSeconds(3))
				.ignoring(NoSuchElementException.class);
		
		
		
		WebElement ele=(WebElement) wait.until(new Function<WebDriver,WebElement>() {

			public WebElement apply(WebDriver driver) {

				if(driver.findElement(By.xpath("//div[@id=\"finish\"]/h4")).isDisplayed())
				{
					return driver.findElement(By.xpath("//div[@id=\"finish\"]/h4"));
				}
				else
				{
					return null;
				}
				
			
			}
		});						
		System.out.println(ele.getText());
		
	}
	
	@Test(enabled = false)
	public void fluentWait1() throws InterruptedException
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		ChromeDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/dynamic_loading/1");
		driver.findElement(By.xpath("//div[@id=\"start\"]/button")).click();
		
		
		
		Wait<WebDriver> wait=new FluentWait<WebDriver>(driver)
				.withTimeout(Duration.ofSeconds(10))
				.pollingEvery(Duration.ofSeconds(3))
				.ignoring(NoSuchElementException.class);
		
		
		Function<WebDriver,WebElement> f=new Function<WebDriver,WebElement>()
				{

					public WebElement apply(WebDriver driver) {

						if(driver.findElement(By.xpath("//div[@id=\"finish\"]/h4")).isDisplayed())
						{
							return driver.findElement(By.xpath("//div[@id=\"finish\"]/h4"));
						}
						else
						{
							return null;
						}
					
					}
				};		
		
		WebElement ele=wait.until(f);	
		
		System.out.println(driver.findElement(By.xpath("//div[@id=\"finish\"]/h4")).getText());
		
		
	}
	
	
}
