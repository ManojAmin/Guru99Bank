package com.Automation;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class GoogleSuggestion {

	@Test
	public void printGoogleSuggestion()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.name("india")).sendKeys("selenium");		
		List<WebElement> ele=driver.findElements(By.xpath("//ul[@role='listbox']//li"));
		//ul[@role='listbox']//li
		//div[@class='UUbT9']/div[2]/div[2]/ul/div/ul/li/div/div[2]/div[1]/span
		System.out.println(ele.size());
		
		System.out.println("suggestion for selenium are :");
		for (WebElement s : ele) {			
			if(s.getText().equalsIgnoreCase("india"))
			{
				s.click();
			}
		}
		
		
	}
	
	@Test(enabled = false)
	public void printAmazonSuggestion()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.amazon.in/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.id("twotabsearchtextbox")).sendKeys("laptop");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
		List<WebElement> ele=driver.findElements(By.xpath("//div[@id='nav-flyout-searchAjax']/div/div/div/div/span"));
		System.out.println(ele.size());
		
		System.out.println("suggestion for laptops  are :");
		for (WebElement s : ele) {
			
			System.out.println(s);
			
		}
	}
	
	@Test(enabled = false)
	public void printExampleSuggestion()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.rahulshettyacademy.com/AutomationPractice/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.id("autocomplete")).sendKeys("ind");
		
		List<WebElement> ele=driver.findElements(By.xpath("//ul[@id='ui-id-1']/li/div"));
		System.out.println(ele.size());
		
		System.out.println("suggestion for laptops  are :");
		
		for (WebElement s : ele) {
			
			System.out.println(s.getText());
			
		}
	
	}
}
