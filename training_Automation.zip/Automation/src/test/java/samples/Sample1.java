package samples;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

public class Sample1 {
	
	@Test
	public void alert1()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\driver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://demoqa.com/alerts");
		driver.manage().window().maximize();
		//	driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.id("timerAlertButton")).click();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		
WebDriverWait exwait=new WebDriverWait(driver,25);
    	
    	Alert isAlretPrest=exwait.until(ExpectedConditions.alertIsPresent());
    	System.out.println(isAlretPrest);
    	if(isAlretPrest==null)
    	{
    		
    		System.out.println("Alert  not exists");
    	}
	      else 
	      {
	    	  System.out.println("Alert exists");
	      }
    	isAlretPrest.accept();
		//driver.switchTo().alert().accept();
    	
    	Select s=new Select(driver.findElement(By.id("timerAlertButton")));
    	//driver.switchTo().def
	}

}
