package stepDef;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import common.BaseClass;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Hook extends BaseClass {

	private BaseClass base;

	public Hook(BaseClass base) {
		this.base = base;
	}

	@Before
	public void initDriver() {
		System.out.println("Open browser");
		//System.setProperty("webdriver.chrome.driver", "lib/chromedriver 3");
		WebDriverManager.chromedriver().setup();
		base.driver = new ChromeDriver();
		base.driver.manage().window().maximize();
		base.driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
	}

	@After
	public void teardown() {
		System.out.println("Close browser");
		base.driver.quit();
	}

	/*
	 * @Before public WebDriver beforeScenario() {
	 * System.out.println("This will run before the Scenario");
	 * WebDriverManager.chromedriver().setup(); driver = new ChromeDriver(); return
	 * driver; }
	 * 
	 * @After public void afterScenario() {
	 * System.out.println("This will run after the Scenario"); }
	 */
}
