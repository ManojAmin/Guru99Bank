package stepDef;

import org.junit.Assert;
import org.openqa.selenium.By;

import common.BaseClass;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps extends BaseClass {

	private BaseClass base; 
	
	 public LoginSteps(BaseClass base) { this.base = base; }
	

	 @Given("user is on Login Page")
	 public void user_is_on_login_page() {
	     
		 base.driver.get("http://automationpractice.com/index.php");
	 }
	 @When("user has provided valid credentials {string} {string} {string} {string} {string} {string}")
	 public void user_has_provided_valid_credentials(String string, String string2, String string3, String string4, String string5, String string6, DataTable dataTable) {
	     
	 	
	 }
	 @Then("user should be able to login")
	 public void user_should_be_able_to_login() {    
	 	
	 }




	
}
