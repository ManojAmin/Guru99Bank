package common;

import org.openqa.selenium.WebDriver;

public class BaseClass {
	public String baseURL = "http://automationpractice.com";
	public WebDriver driver;

}
