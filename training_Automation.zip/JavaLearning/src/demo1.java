
public class demo1 {

	public static int f1=0,f2=1,f3,n=0;
	public static void main(String[] args) {
		
		int count=10;   
		System.out.println("fibboncai series are :"+f1);
		System.out.println(f2);
		fib(count-2);
			}
	
	public static void  fib(int n)
	{
		while(n>=0)
		{
			int f3=f1+f2;
			System.out.println(f3);
			f1=f2;
			f2=f3;
			//n++;
			fib(n-1);
		}

	}

}
