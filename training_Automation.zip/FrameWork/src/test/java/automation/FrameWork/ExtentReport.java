package automation.FrameWork;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReport {

	public  ExtentReports generateReport()
	{
		String reportPath=System.getProperty("user.dir")+"\\report\\reports.html";
		ExtentSparkReporter sparkReport=new ExtentSparkReporter(reportPath);
		sparkReport.config().setDocumentTitle("FramWork Report");
		sparkReport.config().setReportName("Web Auomation Report");
		
		ExtentReports report=new ExtentReports();
		report.attachReporter(sparkReport);
		return report;
	}
}
