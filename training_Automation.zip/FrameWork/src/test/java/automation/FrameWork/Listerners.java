package automation.FrameWork;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;

public class Listerners extends Base implements ITestListener {
	
	ExtentReports report=new ExtentReport().generateReport();
	ExtentTest reportMsg;

	public void onFinish(ITestContext arg0) {
		report.flush();

	}

	public void onStart(ITestContext result) {
		

	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	public void onTestFailure(ITestResult result) {
		WebDriver driver;
		reportMsg.fail(result.getThrowable());
		String methodName=result.getMethod().getMethodName();
		try {
			driver=(WebDriver) result.getTestClass().getRealClass().getDeclaredField("driver").get(result.getInstance());
			generateScrenShot(driver,methodName);
			reportMsg.addScreenCaptureFromPath(generateScrenShot(driver,methodName), methodName);
	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void onTestSkipped(ITestResult arg0) {
		// TODO Auto-generated method stub

	}

	public void onTestStart(ITestResult result) {
		 reportMsg=report.createTest(result.getMethod().getMethodName());
		 

	}

	public void onTestSuccess(ITestResult result) {
		System.out.println("Test passed " + result);
		reportMsg.log(Status.PASS, "Test passed");

	}	
	

}
