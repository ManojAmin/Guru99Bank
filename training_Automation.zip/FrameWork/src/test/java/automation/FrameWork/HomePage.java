package automation.FrameWork;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import pageObject.LandingPage;
import pageObject.LoginPage;

public class HomePage extends Base  {
	
	public Logger log=LogManager.getLogger(Base.class.getName());
	
	WebDriver driver;
	@BeforeMethod
	public void setUp() throws IOException
	{
		System.out.println("in setup");
		driver=driverInitializer();
		log.info("Driver initialized");
		driver.get(pro.getProperty("url"));
		log.info("Url hit successfully");
		
	}
	@Test(dataProvider="loginData")
	public void basePage(String Username,String password) throws IOException
	{			
		LandingPage landing=new LandingPage(driver);
		//landing.getColseSubScriptionPupUp().click();
		landing.getLoginIn().click();
		log.info("cliked on login url ");
		LoginPage login=new LoginPage(driver);
		login.getEmail().sendKeys(Username);
		log.info("email entered");
		login.getPassword().sendKeys(password);
		log.info("password entered");
		System.out.println(Username +":"+password);
		login.getLogin().click();
		log.info("clicked on login with "+Username +" and "+ password);
	}
	
	@DataProvider
	public Object[][] loginData()
	{
		Object[][] credential= new Object[2][2];
		credential[0][0] ="manoj@gmail.com";
		credential[0][1] ="1234";
		
		credential[1][0] ="manoj@tcs.com";
		credential[1][1] ="tcs@760";
	
		return credential;
				
	}
	
	@AfterMethod
	public void excuteAfterTest()	
	{
		driver.close();
	}
}
