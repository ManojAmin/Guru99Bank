package automation.FrameWork;

import static org.testng.Assert.assertEquals;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import pageObject.LandingPage;

public class ValidateTitle extends Base {
	
	public Logger log=LogManager.getLogger(Base.class.getName());
	WebDriver driver;
	
	@BeforeTest
	public void setUp() throws IOException
	{
		driver=driverInitializer();
		driver.get(pro.getProperty("url"));
	}
	@Test
	public void VerifyCourseSectionTitle() throws IOException
	{	
		LandingPage landind=new LandingPage(driver);
		log.info("fetching cource title");
		String title=landind.getCourseTitle().getText();
		log.debug("cource title grabbed " +title);
		assertEquals("FEATURED COURSES123", title);
	}
	
	@AfterTest
	public void excuteAfterTest()	
	{
		driver.quit();
	}

}
