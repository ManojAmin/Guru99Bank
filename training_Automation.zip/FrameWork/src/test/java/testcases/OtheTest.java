package testcases;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.support.ui.Select;

public class OtheTest 
{
	WebDriver driver;
	ChromeOptions option=new ChromeOptions();
	public void other()
	{
		option.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
		option.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
		//option.addArguments("--headless");
		//option.merge(dc);
		System.out.println("chrome browser");
		System.setProperty("webdriver.chrome.driver", "C:\\Automation\\chromedriver.exe");
		driver=new ChromeDriver(option);
		driver.get("https://www.rahulshettyacademy.com/AutomationPractice/");
		WebElement drop=driver.findElement(By.id("dropdown-class-example"));
		Select s=new Select(drop);
		List<WebElement> ss=s.getOptions();
		
		List<String> l=new ArrayList<String>();
		
		for (WebElement webElement : ss) {
			
			l.add(webElement.getText());
		}
		
		Collections.sort(l);
		
		
		
		
	}
	
}
