package testcases;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import automation.FrameWork.Base;

public class TC_LoginTest_001 extends Base {
	
	WebDriver driver;
	
	@BeforeTest
	public void setUp() throws IOException
	{
		this.driver=driverInitializer();
	}
	
	@Test
	public void loginTest()
	{
		driver.get("http://demo.guru99.com/V1/index.php");
	}

}
