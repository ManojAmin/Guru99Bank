package pageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
public class LandingPage {
	
	public WebDriver driver;
	
	public LandingPage(WebDriver driver) {
		super();
		System.out.println("in constructor");
		this.driver = driver;
	}


	By logIN=By.cssSelector("a[href*='sign_in']");
	By subScription_PupUp_Close=By.cssSelector("$(div[class*='sumome-react-svg']");
	By courseTitle=By.xpath("//div[@class='text-center']/h2");
	
	
	public WebElement getLoginIn() {
		return driver.findElement(logIN);
	}
	public WebElement getColseSubScriptionPupUp() {
		//wait.until(ExpectedConditions.visibilityOfElementLocated(subScription_PupUp_Close));
		return driver.findElement(subScription_PupUp_Close);
	}
	
	public WebElement getCourseTitle()
	{
		return driver.findElement(courseTitle);
	}
	

}
