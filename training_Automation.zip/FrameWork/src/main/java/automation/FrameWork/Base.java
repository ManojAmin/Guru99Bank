package automation.FrameWork;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Base {
	public WebDriver driver;
	public Properties pro;
	DesiredCapabilities dc=new DesiredCapabilities();
	//dc.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
	//dc.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	ChromeOptions option=new ChromeOptions();
	
	public WebDriver driverInitializer() throws IOException 
	{		
		pro=new Properties();
		
		FileInputStream file=new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\automation\\FrameWork\\data.properties");
		pro.load(file);
		String browser=pro.getProperty("browser");
		//String browser=System.getProperty("browser");
		System.out.println(" before chrome browser");
		if(browser.equalsIgnoreCase("chrome"))
		{			
			
			option.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS, true);
			option.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
			//option.addArguments("--headless");
			//option.merge(dc);
			System.out.println("chrome browser");
			System.setProperty("webdriver.chrome.driver", "C:\\Automation\\driver\\chromedriver.exe");
			driver=new ChromeDriver(option);
		}
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		System.out.println(driver);
		return driver;
	}
	
	public String generateScrenShot(WebDriver driver,String methodName) throws IOException
	{
		TakesScreenshot ss=(TakesScreenshot) driver;
		File source =ss.getScreenshotAs(OutputType.FILE);
		String destination =System.getProperty("user.dir")+"\\report\\"+methodName+".png";
		FileUtils.copyFile(source, new File(destination));
		return destination;
	
	}
	
}
