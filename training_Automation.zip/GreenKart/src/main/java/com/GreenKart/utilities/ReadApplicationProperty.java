package com.GreenKart.utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class ReadApplicationProperty {
	
	private Properties pro;
	private FileInputStream input; 
	
	
	public ReadApplicationProperty() {

		pro=new Properties();
		try {
			input=new FileInputStream("C:\\Automation\\GreenKart\\src\\test\\resources\\application.properties");
			pro.load(input);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	
	}

	
	public String getUrl()
	{
		return pro.getProperty("url");
	}

}
