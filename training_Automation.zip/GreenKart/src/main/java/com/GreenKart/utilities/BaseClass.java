package com.GreenKart.utilities;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {

	private ReadApplicationProperty applicationFile;
	WebDriver driver;
	public WebDriver launchBrowser()
	{
		ChromeOptions co=new ChromeOptions();
		co.addArguments("--remote-allow-origins=*");
		WebDriverManager.chromedriver().setup();
		driver=new ChromeDriver(co);
		
		applicationFile=new ReadApplicationProperty();
		
		driver.get(applicationFile.getUrl());
		
		return driver;
	}
}
