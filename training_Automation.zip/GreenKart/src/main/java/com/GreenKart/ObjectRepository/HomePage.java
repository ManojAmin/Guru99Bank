package com.GreenKart.ObjectRepository;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {

	WebDriver driver;
	public HomePage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	@FindBy(xpath = "//button[text()='ADD TO CART'][1]")
	private WebElement firstAddToCartButton;
	
	@FindBy(xpath = "//a[@class='cart-icon']")
	private WebElement cartButton;
	
	@FindBy(xpath = "(//div[@class='product']/p[@class='product-price'])[1]")
	private WebElement firstProductPrice;
	
	@FindBy(xpath = "//div[@class='cart-info'] //tr[2]/td[3]/strong")
	private WebElement cartPrice;
	
	@FindBy(xpath = "//button[text()='PROCEED TO CHECKOUT']")
	private WebElement proceedeToCheckOutButton;
	
	public void clickOnFirstAddToCartBotton()
	{
		firstAddToCartButton.click();
	}
	
	public void clickOnCartbutton() 
	{
		cartButton.click();
	}
	
	public String getFirstProductPrice()
	{
		return firstProductPrice.getText();
	}
	
	public String getCartPrice()
	{
		return cartPrice.getText();
	}
	
	public void clickOnProceedeToCheckOutButton()
	{
		proceedeToCheckOutButton.click();
	}
}
