package com.GreenKart.testCases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import com.GreenKart.utilities.BaseClass;

public class TestCase1 extends BaseClass {

	WebDriver driver;
	
	
	@Test
	public void demoTest()
	{
		launchBrowser();
	}
}
