package com.GreenKart.testCases;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.GreenKart.ObjectRepository.HomePage;
import com.GreenKart.ObjectRepository.PaymentPage;
import com.GreenKart.utilities.BaseClass;

import junit.framework.Assert;

public class ItemBookingEndToEndFlow extends BaseClass{
	
	WebDriver driver;
	HomePage home;
	PaymentPage payment;
	
	@BeforeMethod
	public void setUp()
	{
		driver=launchBrowser();
		home=new HomePage(driver);
		payment=new PaymentPage(driver);
	}
	@Test
	public void bookItem()
	{
		home.clickOnFirstAddToCartBotton();
		String Itemprice=home.getFirstProductPrice();
		System.out.println(Itemprice);
		home.clickOnCartbutton();
		String cartAmount=home.getCartPrice();
		Assert.assertEquals(Itemprice,cartAmount );
		home.clickOnProceedeToCheckOutButton();	
		Assert.assertEquals(cartAmount,payment.getTotalAmount() );
		
		
		
	}

}
