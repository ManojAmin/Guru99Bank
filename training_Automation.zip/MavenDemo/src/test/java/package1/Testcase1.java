package package1;

import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Testcase1 {
	
		
	@Test
	public void printGoogleSuggestion()
	{
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\driver\\chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		driver.findElement(By.name("q")).sendKeys("selenium");
		
		List<WebElement> ele=driver.findElements(By.xpath("//ul[@role='listbox']//li"));
		//ul[@role='listbox']//li
		//div[@class='UUbT9']/div[2]/div[2]/ul/div/ul/li/div/div[2]/div[1]/span
		System.out.println(ele.size());
		
		System.out.println("suggestion for selenium are :");
		for (WebElement s : ele) {			
			System.out.println(s.getText());
			
		}
	}

}
