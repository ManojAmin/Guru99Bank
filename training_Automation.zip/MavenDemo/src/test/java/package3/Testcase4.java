package package3;

import java.util.ArrayList;
import java.util.Arrays;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import junit.framework.Assert;

public class Testcase4 {
	
	@Test
	public void QAAcademycourseTitle()
	{
		/*
		 * System.setProperty("webdriver.chrome.driver",
		 * "C:\\Automation\\driver\\chromedriver.exe"); WebDriver driver=new
		 * ChromeDriver(); driver.get("http://www.qaclickacademy.com/");
		 * driver.manage().window().maximize(); String
		 * title=driver.findElement(By.xpath("//section[@id='content']/div/div/h2")).
		 * getText(); //FEATURED COURSES Assert.assertEquals("Featured Courseses",
		 * title);
		 * 
		 * ArrayList<String> list = new ArrayList<String>(); list.add("Apple");
		 * list.add("Orange"); list.add("Banana");
		 * 
		 * int[] n= {15,90,22,66}; Arrays.asList(n);
		 */
		
		for (int i = 0; i <= 4; i++) {
			for (int j = 0; j <= i; j++)
			{
				System.out.print("*");
			}
			System.out.println("");

		}
	    
	}

}
