package com.Guru99Bank.modules;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class SampleSD {
	
	@Given("^Exam time table in ([a-z]*) season$")
	public void exam_time_table_in_summer_season(String s) {
		System.out.println(" in given 1"+s);
	}

	@When("test condtion")
	public void test_condtion() {
		System.out.println(" in when 1");
	}
	@Then("condtion")
	public void condtion() {
		System.out.println(" in then 1");
	}

}
