package pageObjectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {

	WebDriver driver;

	public LoginPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	By userName=By.id("userName");
	By password=By.id("password");
	By loginButton=By.id("login");
	
	public void enterUserName(String uname)
	{
		driver.findElement(userName).sendKeys(uname);
	}
	
	public void enterPassword(String pwd) 
	{
		driver.findElement(password).sendKeys(pwd);
	}
	
	public ProfilePage clickonLogin()
	{
		driver.findElement(loginButton).click();
		
		return new ProfilePage(driver);
	}
}
