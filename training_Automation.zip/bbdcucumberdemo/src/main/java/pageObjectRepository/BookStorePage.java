package pageObjectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utilities.Scrolling;

public class BookStorePage {
	
	WebDriver driver;
	Scrolling scroll;

	public BookStorePage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	By firstBookInTheList=By.xpath("(//*[contains(@id, 'see-book')])[1]");
	By addToCollection=By.xpath("//button[text()='Add To Your Collection']");
	
	
	public void selectFirstBook()
	{
		driver.findElement(firstBookInTheList).click();
	}
	public String selectFirstBookText()
	{
		return driver.findElement(firstBookInTheList).getText();
	}
	
	
	public void clickAddToCollection()
	{
		driver.findElement(addToCollection).click();
	}
	
	public void scrollTillAddToCollectionButton()
	{
		scroll=new Scrolling(driver);
		scroll.scrollIntoView(addToCollection);
	}
	
	public void scrollTillFirstBookInTheList()
	{
		scroll=new Scrolling(driver);
		scroll.scrollIntoView(firstBookInTheList);
	}

}
