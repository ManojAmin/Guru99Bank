package pageObjectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import utilities.Scrolling;

import org.apache.log4j.Logger;

public class ProfilePage {
	
	public static Logger logger=Logger.getLogger("BDDFrameWork");
	WebDriver driver;
	Scrolling scroll;
	
	public ProfilePage(WebDriver driver) {
		super();
		this.driver = driver;
	}	
	
	By loggedInUserNameOnProfilePage=By.id("userName-value");
	By gotoStore=By.id("gotoStore");
	By profile=By.xpath("//ul[@class='menu-list'] //span[text()='Profile']");
	By profilebookAdded=By.id("see-book-Git Pocket Guide");
	
	
	public String getLoggedInUserNameOnProfilePage()
	{
		return driver.findElement(loggedInUserNameOnProfilePage).getText();
	}
	
	
	public void clickonGotoBookStore()
	{
		driver.findElement(gotoStore).click();
	}
	
	public void clickOnProfile()
	{
		driver.findElement(profile).click();
	}
	public void scrollDown()
	{
		scroll=new Scrolling(driver);
		scroll.scrollIntoView(gotoStore);
	}
	
	public void scrollToProfile()
	{
		scroll=new Scrolling(driver);
		scroll.scrollIntoView(profile);
	}
	public String bookAddedInProfile() {
		return driver.findElement(profilebookAdded).getText();
	}
}
