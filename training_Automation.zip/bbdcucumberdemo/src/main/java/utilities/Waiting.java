package utilities;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Waiting {
	WebDriver driver;

	public Waiting(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	public void waitFor10seconds()
	{
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	
//	public void webDriverWait()
//	{
//		WebDriverWait wait1= new WebDriverWait(driver,3);
//		wait1.until(ExpectedConditions.alertIsPresent());
//	}

}
