package utilities;

import java.io.FileInputStream;
import java.util.Properties;

public class BaseURLUtility {
	Properties pro;
	public BaseURLUtility()
	{
		try {
			pro=new Properties();
			FileInputStream f=new FileInputStream("C:\\Automation\\bbdcucumberdemo\\src\\test\\resources\\credential.properties");
			pro.load(f);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
	
	public String getUrl()
	{
		return pro.getProperty("url");
	}
	
	public String getUserName()
	{
		return pro.getProperty("user");
	}
	
	public String getPassword()
	{
		return pro.getProperty("password");
	}
}
