package utilities;

public class ConstantText {
	public final static String ProfilePageTitle="Profile";

}
