package utilities;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;

public class Scrolling {
	WebDriver driver;
	public static Logger logger=Logger.getLogger("BDDFramework");
	JavascriptExecutor j;
	
	public Scrolling(WebDriver driver) {
		super();
		logger.info("in constructor of Scrolling");
		this.driver = driver;
		j=(JavascriptExecutor)driver;
	}

	
	public void scrollToBottom()
	{
		
		logger.info("in scrollToBottom of Scrolling class");
		j.executeScript("window.scrollTo(0, document.body.scrollHeight)");
	}
	
	public void scrollIntoView(By locator)
	{
		j.executeScript("arguments[0].scrollIntoView();", driver.findElement(locator));
	}
}
