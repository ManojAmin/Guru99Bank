package baseClass;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;
import utilities.BaseURLUtility;

public class Base {

	public static Logger logger;
	BaseURLUtility urlUtil;
	WebDriver driver;
	public WebDriver driverInitialization()
	{
		logger=Logger.getLogger("BDDFrameWork");
		PropertyConfigurator.configure("Log4j.properties");
		
		//System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		// driver=new ChromeDriver();
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		 logger.info("driver launched");
		 urlUtil=new BaseURLUtility();
		 
		 driver.get(urlUtil.getUrl());
		 logger.info("navigated to base url");
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 return driver;
		 
	}
	
	public String username()
	{
		return urlUtil.getUserName();
	}
	
	public String password()
	{
		return urlUtil.getPassword();
	}
}
