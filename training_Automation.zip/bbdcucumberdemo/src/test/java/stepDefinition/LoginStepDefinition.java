package stepDefinition;

import static junit.framework.Assert.assertEquals;

import org.openqa.selenium.WebDriver;

import baseClass.Base;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjectRepository.BookStoreHome;
import pageObjectRepository.HomePage;
import pageObjectRepository.LoginPage;
import pageObjectRepository.ProfilePage;
import utilities.Scrolling;

public class LoginStepDefinition extends Base {

		WebDriver driver;
		HomePage homepage;
		Scrolling scroll;
		BookStoreHome bookStoreHome;
		LoginPage loginpage;
		ProfilePage profilePage;
		
	 	@Given("^Enter the URL and navigate to login page$")
	    public void enter_the_url_and_navigate_to_login_page() {
	 		driver=driverInitialization();
	 		homepage=new HomePage(driver);
	 		scroll=new Scrolling(driver);
	 		bookStoreHome=new BookStoreHome(driver);
	 		
	 		scroll.scrollToBottom();
	 		homepage.clickOnBookStoreApplication();
	 		scroll.scrollToBottom();
	 		bookStoreHome.ClickOnLoginInMenuList();
	 		logger.info("clicked on login in menu list");
	    }

	    @When("^provide username and password and login$")
	    public void provide_username_and_password_and_login() {
	    	
	    	loginpage=new LoginPage(driver);
	    	loginpage.enterUserName(username());
	    	logger.info("User name entered");
	    	loginpage.enterPassword(password());
	    	logger.info("password entered");
	    	profilePage =loginpage.clickonLogin();
	    	logger.info("clicked on login button");	    	
	    	
	    }

	    @Then("^verify user logged in successfully$")
	    public void verify_user_logged_in_successfully() {
	    	String username=profilePage.getLoggedInUserNameOnProfilePage();
	    	logger.debug("logged in user name on profile page : "+username);
	    	assertEquals(username(), username);
	    	
	    }
}
