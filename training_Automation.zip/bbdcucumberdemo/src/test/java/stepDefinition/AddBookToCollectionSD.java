package stepDefinition;


import org.openqa.selenium.WebDriver;

import baseClass.Base;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjectRepository.BookStoreHome;
import pageObjectRepository.BookStorePage;
import pageObjectRepository.HomePage;
import pageObjectRepository.LoginPage;
import pageObjectRepository.ProfilePage;
import utilities.Alerts;
import utilities.Scrolling;
import utilities.Waiting;

public class AddBookToCollectionSD extends Base{

	WebDriver driver;
	HomePage homepage;
	Scrolling scroll;
	BookStoreHome bookStoreHome;
	LoginPage loginpage;
	ProfilePage profilePage;	
	BookStorePage bookstore;
	Waiting wait;
	Alerts alert;

	@Given("^Login into the application and navigate to book store page$")
	public void login_into_the_application_and_navigate_to_book_store_page() {

		driver=driverInitialization();
		homepage=new HomePage(driver);
		scroll=new Scrolling(driver);
		bookStoreHome=new BookStoreHome(driver);

		wait=new Waiting(driver);

		scroll.scrollToBottom();
		homepage.clickOnBookStoreApplication();
		scroll.scrollToBottom();
		bookStoreHome.ClickOnLoginInMenuList();
		logger.info("clicked on login in menu list");
		loginpage=new LoginPage(driver);
		loginpage.enterUserName(username());
		logger.info("User name entered");
		loginpage.enterPassword(password());
		logger.info("password entered");
		profilePage =loginpage.clickonLogin();
		logger.info("clicked on login button");
		wait.waitFor10seconds();    	
		profilePage.scrollDown();
		logger.info("scrolled down to book store button in login page");
		profilePage.clickonGotoBookStore();
		logger.info("navigated to book store page");


	}

	@When("^select a book and add to the collection$")
	public void select_a_book_and_add_to_the_collection() {
		bookstore=new BookStorePage(driver);
		bookstore.scrollTillFirstBookInTheList();
		wait.waitFor10seconds();   
		bookstore.selectFirstBook();
		logger.info("Book is selected");
		wait.waitFor10seconds();   
		bookstore.scrollTillAddToCollectionButton();
		logger.info("Scrolled down to click on Add to collection button");
		bookstore.clickAddToCollection();
		logger.info("Clicked on Add to collection button");
		alert = new Alerts(driver);
		alert.alertAccept(); 
		logger.info("Clicked OK on alert");
//		profilePage.scrollToProfile();
//		profilePage.clickOnProfile();	 
//		logger.info("Scrolled to profile page");

	}

	@Then("^go the porfile and check whether book added to collection or not$")
	public void go_the_porfile_and_check_whether_book_added_to_collection_or_not() {
		profilePage.scrollToProfile();
		profilePage.clickOnProfile();	 
		logger.info("Scrolled to profile page");
		if(profilePage.bookAddedInProfile().equals(bookstore.selectFirstBookText())) {
			logger.info("Selected Book is added to the collection");
	}
	}

}
