package pageObjectRepository;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class NewCustomer {

	WebDriver driver;

	public NewCustomer(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	By name=By.name("name");
	By gender=By.xpath("//input[@name='rad1']");
	By dob=By.id("dob");
	By address=By.name("addr");
	By city=By.name("city");
	By state=By.name("state");
	By pin=By.name("pinno");
	By email=By.name("emailid");
	By submit=By.name("sub");
	
	public void SetCustomerName(String cname)
	{
		driver.findElement(name).sendKeys(cname);
	}
	
	public void setGender(String genderValue)
	{
		List<WebElement> genderList=driver.findElements(gender);
		
		if(!genderList.get(1).isSelected()&&genderValue.equalsIgnoreCase("female"))
		{
			genderList.get(1).click();
		}
	}
	
	public void setDOB(String dateOfBirth)
	{
		String[] dates=dateOfBirth.split("/");
		for (String string : dates) {
			driver.findElement(dob).sendKeys(string);
		}
		
	}
	
	public void setAddress(String addressValue)
	{
		driver.findElement(address).sendKeys(addressValue);
	}
	
	public void setCity(String cityValue)
	{
		driver.findElement(city).sendKeys(cityValue);
	}
	
	public void setState(String stateValue)
	{
		driver.findElement(state).sendKeys(stateValue);
	}
	
	public void setPin(String pinValue)
	{
		driver.findElement(pin).sendKeys(pinValue);
	}
	
	public void setEmail(String emailValue)
	{
		driver.findElement(email).sendKeys(emailValue);
	}
}
