package pageObjectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class HomePage {

	WebDriver driver;

	public HomePage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	By homeTitle=By.xpath("//marquee[@class='heading3']");
	By newCustomer=By.xpath("//a[contains(text(),'New Customer')]");
	
	public String getHomepageTitle()
	{
		return driver.findElement(homeTitle).getText();
	}
	
	public NewCustomer clickOnNewCustomer()
	{
		driver.findElement(newCustomer).click();
		return new NewCustomer(driver);
	}
}
