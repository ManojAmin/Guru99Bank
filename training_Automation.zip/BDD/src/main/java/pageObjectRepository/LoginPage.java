package pageObjectRepository;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	
	WebDriver driver;

	public LoginPage(WebDriver driver) {
		super();
		this.driver = driver;
	}
	
	By userId=By.name("uid");
	By password=By.name("password");
	By login=By.name("btnLogin");
	
	public void setUserName(String user) {
		driver.findElement(userId).sendKeys(user);;
	}
	
	public void setPassword(String pwd)
	{
		driver.findElement(password).sendKeys(pwd);;
	}

	public HomePage logIn()
	{
		driver.findElement(login).click();
		return new HomePage(driver);
	}
	
	public void alearHandle()
	{
		driver.switchTo().alert().accept();
	}
}
