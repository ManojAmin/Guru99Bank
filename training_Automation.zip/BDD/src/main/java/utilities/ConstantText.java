package utilities;

public class ConstantText {

	public final static String homePAgeTitle="Welcome To Manager's Page of GTPL Bank";
}
