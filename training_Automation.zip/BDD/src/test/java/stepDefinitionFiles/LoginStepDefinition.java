package stepDefinitionFiles;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import baseClass.Base;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjectRepository.HomePage;
import pageObjectRepository.LoginPage;
import utilities.ConstantText;

public class LoginStepDefinition extends Base {

	WebDriver driver;
	LoginPage loginPage;
	HomePage homePage;
	
	@Given("^User in the login page$")
	public void user_in_the_login_page() {
	    driver=driverInitialization();
	}
	
	@When("^User provided username \"([^\"]*)\" and password \"([^\"]*)\"$")
    public void user_provided_username_something_and_password_something(String user, String pwd) throws Throwable {		
		
		logger.debug("user name passed as :"+user +"and password passed as :"+ pwd);		
		loginPage =new LoginPage(driver);
		
		loginPage.setUserName(user);
		loginPage.setPassword(pwd);
		homePage=loginPage.logIn();
		logger.info("user clicked on login");
		
    }
	
	
	@Then("^User should naviagte to the next page$")
	public void user_should_naviagte_to_the_next_page() {
		logger.info("in Then");		
		
		if(isAlertPreset())
		{			
			logger.info("invalid password");
			Assert.assertTrue(isAlertPreset());
			loginPage.alearHandle();
		}
		else
		{
			logger.info("valid password");			
			String home_page_Text=homePage.getHomepageTitle();			
			logger.debug(home_page_Text);
			Assert.assertEquals(ConstantText.homePAgeTitle, home_page_Text);
		}				
	}

	private boolean isAlertPreset() {
		boolean flag=true;
		try
		{
			driver.switchTo().alert();
		}
		catch(Exception e)
		{
			return flag=false;
		}
		return flag;
		
	}
	
	
	
}
