package stepDefinitionFiles;

import org.openqa.selenium.WebDriver;

import baseClass.Base;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pageObjectRepository.HomePage;
import pageObjectRepository.LoginPage;
import pageObjectRepository.NewCustomer;
import utilities.BaseURLUtility;

public final class NewCustomerStepDefinition extends Base {
	
	WebDriver driver;
	BaseURLUtility baseUtil=new BaseURLUtility();
	LoginPage loginPage;
	HomePage homepage ;
	NewCustomer newCustomer;
	@Given("^user is logged into the applcation with proper detials$")
    public void user_is_logged_into_the_applcation_with_proper_detials() {
       
		System.out.println(" Given");
		driver=driverInitialization();
		loginPage =new LoginPage(driver);
		loginPage.setUserName(baseUtil.getUserName());
		loginPage.setPassword(baseUtil.getPassword());
		homepage=loginPage.logIn();		
		
    }

    @When("^user clicked on New customer tab$")
    public void user_clicked_on_new_customer_tab(){
    	System.out.println("When");
    	newCustomer=homepage.clickOnNewCustomer();
    	
    }
    
    @And("^enter customer details such as \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" $")
    public void enter_customer_details_such_as_something_something_something_something_something_something_something_something_something(String customername, String gender, String dob, String address, String city, String state, String pin, String phone, String email)  {
    	System.out.println("And");
    	newCustomer.SetCustomerName(customername);
    	newCustomer.setGender(gender);
    	newCustomer.setDOB(dob);
    	newCustomer.setAddress(address);
    	newCustomer.setCity(city);
    	newCustomer.setState(state);
    	newCustomer.setPin(pin);
    	newCustomer.setEmail(email);
    }

    @Then("^new customer should get created$")
    public void new_customer_should_get_created() {
    	System.out.println("Then");
    }

    
}
