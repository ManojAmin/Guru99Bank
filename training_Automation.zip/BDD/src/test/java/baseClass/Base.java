package baseClass;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import utilities.BaseURLUtility;

public class Base {
	
	public static Logger logger;
	BaseURLUtility urlUtil;
	WebDriver driver;
	public WebDriver driverInitialization()
	{
		logger=Logger.getLogger("Bank");
		PropertyConfigurator.configure("Log4j.properties");
		
		System.setProperty("webdriver.chrome.driver","C:\\Automation\\chromedriver.exe");
		 driver=new ChromeDriver();
		 
		 urlUtil=new BaseURLUtility();
		 
		 driver.get(urlUtil.getUrl());
		 logger.info("driver launched");
		 driver.manage().window().maximize();
		 driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		 return driver;
		 
	}
	
	public String readUserName()
	{
		return urlUtil.getPassword();
	}
	
	public String readPassword()
	{
		return urlUtil.getPassword();
	}

}
